package choiTaeBaek;

public class FreeBoardMain {

	/*
	 --사진, 영상 매체들의 많은 소비로 인해 글로된 매체들의 선호는 줄어들고 있음.
	 --그런데 FREEBOARD는 mz들도 쉽고 재밌게 접할 수 있는 짧고 이목을 끄는 글들로 사람들과 소통하는것이 주 목적인 프로그램
	*/
	
	public static void main(String[] args) {
		FreeBoardForMain board = new FreeBoardForMain();
		board.start();
	}

}
