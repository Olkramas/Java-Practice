package choiTaeBaek;

public class MessageDao {

}
