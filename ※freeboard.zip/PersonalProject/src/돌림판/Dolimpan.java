package 돌림판;

import java.util.Scanner;

public class Dolimpan {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String[] arr = {"권나윤", "권순범", "김기환", "김다영", "김민진", "김선용", "김준규"
				 		, "박소현", "박주현", "배서진", "서민교", "신강현", "이신화", "이주현"
				 		, "최민규", "최시훈", "표하연"};
		//나 빼고 17명
		System.out.println("다음 발표자는 누구일까요?");
		System.out.println("시작: 엔터");
		scanner.nextLine();
		
		int ranNum = (int)(Math.random()*18);
		for(int i=3; i>0; i--) {
			try {
				Thread.sleep(1000);
				System.out.println("카운트다운: " + i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			Thread.sleep(1000);
			System.out.println();
			System.out.println("=======================");
			System.out.println(" 다음 발표자는 " + arr[ranNum] + "님 입니다!");
			System.out.println("=======================");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		scanner.close();
	}
}
