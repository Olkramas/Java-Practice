package choiTaeBaek;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FreeBoardDao extends DAO{
	Scanner scanner = new Scanner(System.in);

	//여러줄 입력을 위한 메소드
	public String inputContents() {
		String result = "     ";
		int count = 0;
		
		System.out.println("  입력을 시작합니다\n  입력 종료를 원하시면 \"CLOSE\"를 입력하세요");
		System.out.println();
		System.out.print("내용입력 >> ");
		
		while(true) {
			String input = scanner.nextLine();
			
			if(input.equals("CLOSE")) {
				System.out.println("  입력을 종료합니다.");
				break;
			}
			
			count++;
			if(count == 1) {
				result += input + "\n";
			} else {
				result += "     " + input + "\n";
			}
		}
		return result;
	}

	//리스트의 사이즈 반환
	public int totalListSize() {
		String sql = "select count(1) "
				+ "   from   tbl_freeboard ";
		
		int listSize = 0;
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listSize = rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			return listSize;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return listSize;
	}
	
	//리스트의 사이즈 반환(제목 조건에 맞는것들)
	public int totalListSizeCondition(String title) {
		String sql = "select count(1) "
				+ "   from   tbl_freeboard "
				+ "   where  title like ?";
		
		int listSize = 0;
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ("%" + title + "%"));
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listSize = rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			return listSize;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return listSize;
	}
	
	//리스트의 사이즈 반환(닉네임 조건에 맞는것들)
	public int totalListSizeConditionForName (String nickname) {
		String sql = "select count(1) "
				+ "   from   tbl_freeboard "
				+ "   where  nickname like ?";
		
		int listSize = 0;
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listSize = rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			return listSize;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return listSize;
	}
	
	//제목으로 게시물 찾고 리스트 반환하는 메소드
	public List<FreeBoard> selectCondition(String inputTitle) {
		List<FreeBoard> boardList = new ArrayList<>();
		String sql = "select   nickname, "
				+ "            title,"
				+ "            col_content, "
				+ "            likenum,"
				+ "            write_date,"
				+ "            boardNum "
				+ "   from     tbl_freeboard "
				+ "   where    title like ? "
				+ "   order by write_date desc ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ('%' + inputTitle + '%'));
			rs = pstmt.executeQuery();
			while(rs.next()) {
				FreeBoard board = new FreeBoard();
				board.setNickName(rs.getString(1));
				board.setTitle(rs.getString(2));
				board.setContent(rs.getString(3));
				board.setLikeNum(rs.getInt(4));
				board.setWriteDate(rs.getString(5));
				board.setBoardNum(rs.getInt(6));
				boardList.add(board);
			}
			rs.close();
			pstmt.close();
			return boardList;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return boardList;
	}
	
	//닉네임으로 게시물 찾고 리스트 반환하는 메소드
	public List<FreeBoard> selectConditionForName(String nickname) {
		List<FreeBoard> boardList = new ArrayList<>();
		String sql = "select   nickname, "
				+ "            title,"
				+ "            col_content, "
				+ "            likenum,"
				+ "            write_date,"
				+ "            boardNum "
				+ "   from     tbl_freeboard "
				+ "   where    nickname = ? "
				+ "   order by write_date desc ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,nickname);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				FreeBoard board = new FreeBoard();
				board.setNickName(rs.getString(1));
				board.setTitle(rs.getString(2));
				board.setContent(rs.getString(3));
				board.setLikeNum(rs.getInt(4));
				board.setWriteDate(rs.getString(5));
				board.setBoardNum(rs.getInt(6));
				boardList.add(board);
			}
			pstmt.close();
			rs.close();
			return boardList;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return boardList;
	}
	
	//전체 게시물 리스트 반환하는 메소드
	public List<FreeBoard> selectAll() {
		List<FreeBoard> boardList = new ArrayList<>();
		String sql = "select   nickname, "
				+ "            title,"
				+ "            col_content, "
				+ "            likenum,"
				+ "            write_date,"
				+ "            boardNum "
				+ "   from     tbl_freeboard"
				+ "   order by write_date desc ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				FreeBoard board = new FreeBoard();
				board.setNickName(rs.getString(1));
				board.setTitle(rs.getString(2));
				board.setContent(rs.getString(3));
				board.setLikeNum(rs.getInt(4));
				board.setWriteDate(rs.getString(5));
				board.setBoardNum(rs.getInt(6));
				boardList.add(board);
			}
			rs.close();
			pstmt.close();
			return boardList;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return boardList;
	}
	
	//게시물 db에 입력하는 메소드
	public void insertContents(String nickname, String inputTitle, String inputContent) {
		String sql = "insert into tbl_freeboard ("
				+ "          nickname, "
				+ "          title, "
				+ "          col_content, "
				+ "          boardnum ) "
				+ "   values ( ?,"
				+ "            ?, "
				+ "            ?,"
				+ "            board_num_seq.nextval ) ";
		
		
		try {
			conn = getOpen();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.setString(2, inputTitle);
			pstmt.setString(3, inputContent);
			
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  게시글을 업로드했습니다.");
			} else {
				System.out.println("  게시글 업로드를 실패했습니다 \n고객센터로 문의 부탁드립니다.");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//좋아요 인서트, 업데이트 메소드 모음
	public void insertUpdateLikeMenu(int ownBoardNum, String nickname) {
		UserDao udao = new UserDao();
		//좋아요 테이블에 게시물 고유 번호와 좋아요를 누른사람의 닉네임을 넣음.
		insertLike(ownBoardNum, nickname);
		//좋아요 테이블에 입력됨.
		
		//게시물 테이블의 likeNum칼럼의 좋아요 수 업데이트
		updateLikeNum(ownBoardNum);
		//업데이트 됨.
		
		//게시판 테이블의 모든 좋아요수를 더해서 리턴
		int sumOfLike = udao.sumOfLike(ownBoardNum);
//		//유저 테이블의 total_like칼럼의 좋아요 수 업데이트
		
		//아래 메소드 작동함.
//		udao.updateTotalLike(nickname, sumOfLike);
		udao.updateTotalLike(sumOfLike, ownBoardNum);
	}
	
	//전체 게시물) 유저가 인텍스 번호를 입력하면 고유 보드 넘버를 가져오는 메소드
	public int getBoardNumFromDb(int indexNum) {		
		//전체 게시글 목록 boardList에 저장
		List<FreeBoard> boardList = selectAll();		
		//유저가 입력한 인덱스 번호를 원래대로 바꿔서(입력받을때 +1상태임) 해당 board객체를 저장
		FreeBoard board = boardList.get(indexNum - 1);
		
		//보드 객체의 고유 보드 넘버를 가져오기.
		int boardNum = board.getBoardNum();
		return boardNum;
	}
	
	//제목으로 검색한 결과 게시물) 유저가 인텍스 번호를 입력하면 고유 보드 넘버를 가져오는 메소드
	public int getBoardNumFromDbConditionforTitle(int indexNum, String title) {
		//전체 게시글 목록 boardList에 저장
		List<FreeBoard> boardList = selectCondition(title);		
		//유저가 입력한 인덱스 번호를 원래대로 바꿔서(입력받을때 +1상태임) 해당 board객체를 저장
		FreeBoard board = boardList.get(indexNum - 1);
		
		//보드 객체의 고유 보드 넘버를 가져오기.
		int boardNum = board.getBoardNum();
		return boardNum;
	}
	
	//유저 검색한 결과 게시물) 유저가 인텍스 번호를 입력하면 고유 보드 넘버를 가져오는 메소드
	public int getBoardNumFromDbConditionforNick(int indexNum, String nickname) {
		//전체 게시글 목록 boardList에 저장
		List<FreeBoard> boardList = selectConditionForName(nickname);		
		//유저가 입력한 인덱스 번호를 원래대로 바꿔서(입력받을때 +1상태임) 해당 board객체를 저장
		FreeBoard board = boardList.get(indexNum - 1);
		
		//보드 객체의 고유 보드 넘버를 가져오기.
		int boardNum = board.getBoardNum();
		return boardNum;
	}
	
	//좋아요 tbl_list에 게시물번호, 닉네임 입력하는 메소드
	public void insertLike(int boardNum, String nickname) {
		String sql = "insert into tbl_like "
				+ "          (boardnum, "
				+ "           nickname) "
				+ "   values (?, "
				+ "           ?) ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);
			pstmt.setString(2, nickname);
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  좋아요를 보냈습니다!");
				System.out.println();
			} else {
				System.out.println("  좋아요 보내기 실패");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//댓글 입력하는 메소드
	//전체 게시물의 댓글리스트 출력 selectAll() 메소드 사용함
	public void insertComment(int boardNum, String nickname, String comment) {
		String sql = "insert into tbl_comment "
				+ "          (boardNum, "
				+ "           nickname, "
				+ "           col_comment) "
				+ "   values (?,"
				+ "           ?, "
				+ "           ?) ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);
			pstmt.setString(2, nickname);
			pstmt.setString(3, comment);
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  댓글달기 완료!");
			} else {
				System.out.println("  댓글달기 실패");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
	}
	
	//전체 게시물) 유저가 인덱스 번호를 입력하면 해당 게시물의 세부 사항 출력
	//유저가 인덱스 번호를 선택하면 그에 맞는 정보들을 가져옴(게시물 전체 목록)
	public String selectContent(int indexNum) {
		
		//전체 게시글 목록 boardList에 저장
		List<FreeBoard> boardList = selectAll();
		
		//유저가 입력한 인덱스 번호를 원래대로 바꿔서(입력받을때 +1상태임) 해당 board객체를 저장
		FreeBoard board = boardList.get(indexNum - 1);
		
		//하나씩 출력
		System.out.println("  작성자 / 제목 / 좋아요 / 작성일 순서입니다.\n");
		return "  " + board.getNickName() + "\t\t" + board.getTitle() + "\t\t" + board.getLikeNum() + "\t" + board.getWriteDate() 
					+ "\t\n\n  내용 >> \n" + board.getContent(); 
	}
	
	//제목으로 검색한 게시물) 유저가 인덱스 번호를 입력하면 해당 게시물의 세부 사항 출력
	//유저가 인덱스 번호를 선택하면 그에 맞는 정보들을 가져옴(게시물 제목으로 찾기 목록)
	public String selectContentConditionForTitle(String title, int indexNum) {
		List<FreeBoard> boardList = selectCondition(title);
		
		FreeBoard board = boardList.get(indexNum - 1);
		
		System.out.println("  작성자 / 제목 / 좋아요 / 작성일 순서입니다.\n");
		return "  " + board.getNickName() + "\t\t" + board.getTitle() + "\t\t" + board.getLikeNum() + "\t" + board.getWriteDate() 
		+ "\t\n\n  내용 >> \n" + board.getContent(); 
	}
	
	//유저 검색으로 나온 게시물) 유저가 인덱스 번호를 입력하면 해당 게시물의 세부 사항 출력
	//유저가 인덱스 번호를 선택하면 그에 맞는 정보들을 가져옴(작성자 이름으로 찾기 목록)
	public String selectContentConditionForName(String nickname, int indexNum) {
		List<FreeBoard> boardList = selectConditionForName(nickname);
		
		FreeBoard board = boardList.get(indexNum - 1);
		
		System.out.println("  작성자 / 제목 / 좋아요 / 작성일 순서입니다.\n");
		return "  " + board.getNickName() + "\t\t" + board.getTitle() + "\t\t" + board.getLikeNum() + "\t" + board.getWriteDate() 
		+ "\t\n\n  내용 >> \n" + board.getContent(); 
	}
	
	//전체 게시물 리스트 출력
	//게시물 전체리스트 출력
	public int showBoardList(int pageNum) {
		//어레이 리스트 선언
		List<FreeBoard> boardList = new ArrayList<>();
		
		//모든 게시글 리스트 boardList에 저장
		boardList = selectAll();
		
		//모든 게시글 리스트의 리스트 사이즈 구하기(db에서 count)
		int lastPage = totalListSize();
		
		
		if(lastPage < pageNum) {
			pageNum = lastPage-5;
		}
		System.out.println("  인덱스 번호 / 작성자 / 제목 / 좋아요 / 작성일 순서입니다.\n");
		for(int i=pageNum; i<pageNum+5 && i<totalListSize(); i++ ) {
			String title = boardList.get(i).getTitle();
		    if (title.length() > 10) {
		        title = title.substring(0, 10) + "....";
		    } else if(title.length() < 7){
		    	title += "\t\t";
		    } else {
		    	title += "\t";
		    }
		    System.out.printf("  [%d]  %-10s \t%-10s\t\t%-5d \t%s \n",
		                      (i + 1),
		                      boardList.get(i).getNickName(),
		                      title,
		                      boardList.get(i).getLikeNum(),
		                      boardList.get(i).getWriteDate()
		    				  );
		}
		return lastPage;
		//5행씩 출력하기
	}
	
	//제목으로 검색했을 때 게시물 리스트 출력
	//제목으로 검색하기 리스트의 사이즈 리턴
	public int showBoardListConditionforTitle(int pageNum, String inputTitle) {
		List<FreeBoard> boardList = selectCondition(inputTitle);
		int lastPage = totalListSizeCondition(inputTitle);
		
		if(lastPage < pageNum) {
			pageNum = lastPage-5;
		}
		
		System.out.println("  인덱스 번호 / 작성자 / 제목 / 좋아요 / 작성일 순서입니다.\n");
		for(int i=pageNum; i<pageNum+5 && i<lastPage; i++ ) {
			
			String title = boardList.get(i).getTitle();
		    if (title.length() > 10) {
		        title = title.substring(0, 10) + "....";
		    } else if(title.length() < 7){
		    	title += "\t\t";
		    } else {
		    	title += "\t";
		    }
		    System.out.printf("  [%d]  %-10s \t%-10s\t\t%-5d \t%s \n",
		                      (i + 1),
		                      boardList.get(i).getNickName(),
		                      title,
		                      boardList.get(i).getLikeNum(),
		                      boardList.get(i).getWriteDate()
		    				  );
		}
		return lastPage;
	}
	
	//유저이름 검색했을 때 게시물 리스트 출력
	//닉네임으로 검색하기 본인 게시글 수정용, 유저 검색 후 게시물 출력용
	public int showBoardListConditionForName(int pageNum, String nickname) {
		List<FreeBoard> boardList = selectConditionForName(nickname);
		int lastPage = totalListSizeConditionForName(nickname);
		
		if(lastPage < pageNum) {
			pageNum = lastPage-5;
		}
		
		System.out.println("  인덱스 번호 / 작성자 / 제목 / 좋아요 / 작성일 순서입니다.\n");
		for(int i=pageNum; i<pageNum+5 && i<lastPage; i++ ) {
			
			String title = boardList.get(i).getTitle();
		    if (title.length() > 10) {
		        title = title.substring(0, 10) + "....";
		    } else if(title.length() < 7){
		    	title += "\t\t";
		    } else {
		    	title += "\t";
		    }
		    System.out.printf("  [%d]  %-10s \t%-10s\t\t%-5d \t%s \n",
		                      (i + 1),
		                      boardList.get(i).getNickName(),
		                      title,
		                      boardList.get(i).getLikeNum(),
		                      boardList.get(i).getWriteDate()
		    				  );
		}
		
		return lastPage;
	}
	
	//본인 게시물 수정해서 업데이트 하는 메소드
	//본인 게시물 올리기 메소드
	public void updateContentConditionForName(String nickname, int indexNum, String AftTitle, String AftContent) {
		List<FreeBoard> boardList = selectConditionForName(nickname);
		
		FreeBoard board = boardList.get(indexNum - 1);
		
		
		String sql = "update tbl_freeboard "
				+ "   set    title=?, "
				+ "          col_content=?"
				+ "   where  title=? "
				+ "   and    col_content=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, AftTitle);
			pstmt.setString(2, AftContent);
			pstmt.setString(3, board.getTitle());
			pstmt.setString(4, board.getContent());
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  \"수정 성공\"");
			} else {
				System.out.println("  \"수정 실패\"");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	//본인 게시물 삭제 메소드
	//게시글 삭제 메소드
	public void delContentConditionForName(String nickname, int indexNum) {
		List<FreeBoard> boardList = selectConditionForName(nickname);
		
		FreeBoard board = boardList.get(indexNum - 1);
		
		String sql = "delete from    tbl_freeboard "
				+ "   where   title=? "
				+ "   and     col_content=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getContent());
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  \"삭제 성공\"");
			} else {
				System.out.println("  \"삭제 실패\"");
			}
			pstmt.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
				
	}
	
	//tbl_like에서 게시물 번호를 조건으로 총 몇건의 좋아요가 입력됐는지 tbl_freeboard에 업데이트 하는 메소드
	//좋아요를 누른 후 tbl_freeboard의 likeNum컬럼에 좋아요 수를 업데이트.
	public void updateLikeNum(int boardNum) {
		String sql = "update tbl_freeboard "
				+ "   set    likeNum = (select count(1) "
				+ "                     from   tbl_like "
				+ "                     where  boardnum=?) "
				+ "   where  boardnum=?";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);
			pstmt.setInt(2, boardNum);
			pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	//게시물 고유 번호를 조건으로 댓글리스트 출력
	//댓글들 리스트로 가져오기
	public String commentList(int boardNum) {
		String allComment = "";
		String sql = "select nickname,"
				+ "          col_comment "
				+ "   from   tbl_comment "
				+ "   where  boardnum=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				allComment += "  닉네임: " + rs.getString(1) + "\n  내용 >> \n" + rs.getString(2) + "\n";
			}
			rs.close();
			pstmt.close();
			return allComment;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return allComment;
	}
	
	//메세지 보내기 메소드
	public void sendMessage(String nickname, String recipient, String message) {
		String sql = "insert into tbl_message ( "
				+ "          nickname, "
				+ "          recipient, "
				+ "          col_message )"
				+ "   values (?, "
				+ "           ?, "
				+ "           ?) ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.setString(2, recipient);
			pstmt.setString(3, message);
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  \"메세지 보내기 성공\"");
			} else {
				System.out.println("  메세지 발송 실패\n  고객센터에 문의해주세요.");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//메세지의 리스트를 db에서 가져와서 리턴
	public List<Message> getMessageListFromDb(String nickname) {
		List<Message> messageList = new ArrayList<>();
		
		String sql = "select nickname,"
				+ "          recipient,"
				+ "          col_message,"
				+ "          send_date "
				+ "   from   tbl_message "
				+ "   where  nickname=? "
				+ "   or     recipient=? "
				+ "   order by send_date desc";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.setString(2, nickname);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Message message = new Message();
				message.setNickname(rs.getString(1));
				message.setRecipient(rs.getString(2));
				message.setColMessage(rs.getString(3));
				message.setSendDate(rs.getString(4));
				messageList.add(message);
			}
			rs.close();
			pstmt.close();
			return messageList;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return messageList;
	}
	
	//메세지 리스트의 사이즈를 db에서 직접 가져옴
	public int getMessageListSize(String nickname) {
		int MessageListSize = 0;
		
		String sql = "select count(1) "
				+ "   from   tbl_message "
				+ "   where  nickname=? "
				+ "   or    recipient=? "; 
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.setString(2, nickname);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				MessageListSize = rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			return MessageListSize;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return MessageListSize;
	}
	
	//메세지 리스트 출력
	public int showMessageList(int pageNum, String nickname) {
		//어레이 리스트 선언
		List<Message> messageList = new ArrayList<>();
		
		//모든 게시글 리스트 boardList에 저장
		messageList = getMessageListFromDb(nickname);
		
		//모든 게시글 리스트의 리스트 사이즈 구하기(db에서 count)
		int lastPage = getMessageListSize(nickname);
		
		if(lastPage < pageNum) {
			pageNum = lastPage-5;
		}
		System.out.println("  인덱스 번호 / 보낸사람 / 받은사람 / 보낸 날짜 / 내용 순서입니다.\n");
		for(int i=pageNum; i<pageNum+5 && i<lastPage; i++) {
			System.out.printf("  [%d]  %-10s %-10s\t%s \n  내용 >>\n %s\n\n", 
			            (i + 1), messageList.get(i).nickname, messageList.get(i).recipient, 
			            messageList.get(i).sendDate, messageList.get(i).colMessage);
		}
		
		return lastPage;
		//5행씩 출력하기
	}

	//좋아요를 누를때 tbl_like테이블에서 해당 게시물 번호의 유저 이름이 있으면 안된다고 출력
	public String noReLike(int ownBoardNum, String nickname) {
		String checkNick = "";
		String sql = "select nickname "
				+ "   from   tbl_like "
				+ "   where  boardnum=? "
				+ "   and    nickname=?  ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ownBoardNum);
			pstmt.setString(2, nickname);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				checkNick = rs.getString(1);
			}
			rs.close();
			pstmt.close();
			return checkNick;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return checkNick;
	}

	//tbl_like에 닉네임으로 입력한 좋아요들 이름 새로운 이름으로 모두 업데이트
	public void changeNickOnTblLike(String oriNick, String newNick) {
		String sql = "update tbl_like "
				+ "   set    nickname=? "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newNick);
			pstmt.setString(2, oriNick);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//tbl_freeboard에 닉네임으로 입력한 게시물 이름 모두 업데이트
	public void changeNickOnTblBoard(String oriNick, String newNick) {
		String sql = "update tbl_freeboard "
				+ "   set    nickname=? "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newNick);
			pstmt.setString(2, oriNick);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//tbl_comment에 원래 닉네임으로 입력된 댓글 새로운 닉네임으로 모두 업데이트
	public void changeNickOnTblComment(String oriNick, String newNick) {
		String sql = "update tbl_comment "
				+ "   set    nickname=? "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newNick);
			pstmt.setString(2, oriNick);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//tbl_message에 원래 닉네임으로 입력된 이름 새로운 닉네임으로 모두 업데이트
	public void changeNickOnTblMessage(String oriNick, String newNick) {
		String sql = "update tbl_message "
				+ "   set    nickname=? "
				+ "   where  nickname=? "
				+ "   or     recipient=?";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newNick);
			pstmt.setString(2, oriNick);
			pstmt.setString(3, oriNick);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//tbl_like에 저장돼있는 유저의 모든 정보 삭제
	public void delNickOnTblLike(String nickname) {
		String sql = "delete from tbl_like "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//tbl_freeboard에 저장돼있는 유저의 모든 정보 삭제
	public void delNickOnTblFreeboard(String nickname) {
		String sql = "delete from tbl_freeboard "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//tbl_comment에 저장돼있는 유저의 모든 정보 삭제
	public void delNickOnTblComment(String nickname) {
		String sql = "delete from tbl_comment "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	//tbl_message에 저장돼있는 유저의 모든 정보 삭제
	public void delNickOnTblMessage(String nickname) {
		String sql = "delete from tbl_message "
				+ "   where  nickname=?"
				+ "   or     recipient=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.setString(2, nickname);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	//회원탈퇴 후 유저의 모든 기록 삭제
	public void delAllOfLog(String nickname) {
		delNickOnTblLike(nickname);
		delNickOnTblFreeboard(nickname);
		delNickOnTblComment(nickname);
		delNickOnTblMessage(nickname);
	}
}
