package choiTaeBaek;

public class LikeDao extends DAO{
	
	
	
	
}
