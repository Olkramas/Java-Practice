package choiTaeBaek;

import java.sql.SQLException;

public class UserDao extends DAO{
	
	//로그인 메소드
	public User login(String userId, String userPw) {
		String sql = "select  user_id, "
					+ "       nickname "
					+ "from   tbl_user "
					+ "where  user_id=? "
					+ "and    user_pw=? ";
		
		try {
			conn = getOpen();
			

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setNickName(rs.getString(2));
				user.setUserId(rs.getString(1));
				return user;
			}
			rs.close();
			pstmt.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return null;
	}
	
	//회원가입 메소드
	public void join(String userId, String userPw, String name, String nickName, String tel, String stateMessage) {
		String sql = "insert into tbl_user ( "
				+ "          user_id, "
				+ "          user_pw, "
				+ "          nickname, "
				+ "          user_name, "
				+ "          user_tel,"
				+ "          state_message ) "
				+ "   values( "
				+ "          ?, "
				+ "          ?, "
				+ "          ?, "
				+ "          ?, "
				+ "          ?,"
				+ "			 ? ) ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			pstmt.setString(3, nickName);
			pstmt.setString(4, name);
			pstmt.setString(5, tel);
			pstmt.setString(6, stateMessage);
			int rows = pstmt.executeUpdate();
			
			if(rows > 0) {
				System.out.println("  회원가입 성공!");
			} else {
				System.out.println("  회원가입 실패\n  문의전화 010-xxxx-xxxx");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	} //end of join method
	
	//유저 닉네임 검색 후 해당 유저의 프로필 정보 출력
	public User getUser(String nickname) {
		User user = new User();
		String sql = "select nickname, "
				+ "          total_like,"
				+ "          state_message,"
				+ "          user_id "
				+ "   from   tbl_user "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user.setNickName(rs.getString(1));
				user.setTotalLike(rs.getInt(2));
				user.setStateMessage(rs.getString(3));
			} else {
				System.out.println("존재하지 않는 닉네임입니다.");
			}
			rs.close();
			pstmt.close();
			return user;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user;
	}
	
	//닉네임 변경 메소드
	public void updateNick(String OrignalNickname, String updateNickname) {
		String sql = "update tbl_user "
				+ "   set    nickname=? "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, updateNickname);
			pstmt.setString(2, OrignalNickname);
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  닉네임 변경 성공");
			} else {
				System.out.println("  닉네임 변경 실패");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}//end of updateNick
	
	//상태메시지 변경 메소드
	public void updateState(String nickname, String updateState) {
		String sql = "update tbl_user "
				+ "   set    state_message=? "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, updateState);
			pstmt.setString(2, nickname);
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  상태메시지 변경성공");
				
			} else {
				System.out.println("  상태메시지 변경실패");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//아이디 변경 베소드
	public void updateId(String checkId, String checkPw, String newId) {
		String sql = "update tbl_user "
				+ "   set    user_id=? "
				+ "   where  user_id=? "
				+ "   and    user_pw=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newId);
			pstmt.setString(2, checkId);
			pstmt.setString(3, checkPw);
			int rows = pstmt.executeUpdate();
			
			if(rows > 0) {
				System.out.println("  아이디 변경성공");
			} else {
				System.out.println("아이디 또는 비밀번호가 맞지 않습니다 다시 시도해주세요.");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//비밀번호 변경 메소드
	public void updatePw(String checkId, String checkPw, String newpw) {
		String sql = "update tbl_user "
				+ "   set    user_pw=? "
				+ "   where  user_id=? "
				+ "   and    user_pw=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newpw);
			pstmt.setString(2, checkId);
			pstmt.setString(3, checkPw);
			int rows = pstmt.executeUpdate();
			
			if(rows > 0) {
				System.out.println("  비밀번호 변경성공");
			} else {
				System.out.println("아이디 또는 비밀번호가 맞지 않습니다 다시 시도해주세요.");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//계정삭제 메소드
	public void delUser(String checkId, String checkPw) {
		String sql = "delete from tbl_user "
				+ "   where  user_id=? "
				+ "   and    user_pw=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, checkId);
			pstmt.setString(2, checkPw);
			pstmt.executeUpdate();
			
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//아이디 중복체크
	public String noReId(String joinId) {
		String checkId = null;
		
		String sql = "select user_id "
				+ "   from   tbl_user "
				+ "   where  user_id = ? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, joinId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				checkId = rs.getString(1);
			}
			rs.close();
			pstmt.close();
			return checkId;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return checkId;
	}
	
	//닉네임 중복체크
	public String noReNickname(String joinNickname) {
		String checkNick = null;
		
		String sql = "select nickname "
				+ "   from   tbl_user "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, joinNickname);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				checkNick = rs.getString(1);
			}
			rs.close();
			pstmt.close();
			return checkNick;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return checkNick;
	}
	
	//닉네임을 받아서 게시물들의 좋아요 수 총합 구하기
	public int sumOfLike(String nickname) {
		int sumOfLike = 0;
		String sql = "select likenum "
				+ "   from   tbl_freeboard "
				+ "   where  nickname =? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				sumOfLike += rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			return sumOfLike;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return sumOfLike;
	}
	
	//게시물테이블의 좋아요 수를 모두 가져와서 더하기 그리고 그 값을 이 메소드로 받고 유저 테이블에 업데이트
	public void updateTotalLike(String nickname, int sumOfLike) {
		String sql = "update tbl_user "
				+ "   set    total_like=? "
				+ "   where  nickname=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sumOfLike);
			pstmt.setString(2, nickname);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
}
