package choiTaeBaek;

public class Like {
	int boardNum;
	String nickname;
	
	
	public int getBoardNum() {return boardNum;}
	public void setBoardNum(int boardNum) {this.boardNum = boardNum;}
	public String getNickname() {return nickname;}
	public void setNickname(String nickname) {this.nickname = nickname;}
	
}
