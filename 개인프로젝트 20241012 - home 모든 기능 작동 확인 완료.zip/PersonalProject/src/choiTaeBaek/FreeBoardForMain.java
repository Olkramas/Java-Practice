package choiTaeBaek;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FreeBoardForMain {
	Scanner scanner = new Scanner(System.in);
	UserDao udao = new UserDao();
	FreeBoardDao fdao = new FreeBoardDao();
	LikeDao ldao = new LikeDao();
	
	List<FreeBoard> boardList = new ArrayList<>();
	
	//페이지 넘길때 사용
	int pageNum;
	//마지막 페이지 얼마인지 확인용
	int lastPageNum;
	
	String inputTitle;
	String inputContent;
	
	
	//로그인, 회원가입, 종료
	public void start() {
		System.out.println("====FreeBoard에 오신것을 환영합니다====\n");
		System.out.println("  \"FreeBoard\"는 여러분들의 자유로운 "
				+ "  \n생각들을 담아내기 위해 만들어진 프로그램입니다:) \n\n");
		while(true) {
			System.out.println("================================");
			System.out.println("   1.로그인 | 2.회원가입 | 3.종료"); 
			System.out.println("================================");
			System.out.print("   입력 >> ");
			String menuNum = scanner.nextLine();
			System.out.println();
			
			switch(menuNum) {
			case "1":
				System.out.println("  [로그인]");
				//로그인 구현하기
				System.out.print("  아이디 >> ");
				String userId = scanner.nextLine();
				System.out.println(); 
				
				System.out.print("  비밀번호 >> ");
				String userPw = scanner.nextLine();
				System.out.println(); 
				
				//조건 만들어서 로그인 성공하면 menu()메소드 호출하기
				User checkAcc = udao.login(userId.trim(), userPw.trim());

				if(checkAcc == null) {
					System.out.println("  아이디 비밀번호가 정확하지 않습니다.");
					break;
				} else if(checkAcc.getUserId().equals(userId)) {
					System.out.println("  환영합니다 " + checkAcc.getNickName() + "님\n");
					mainMenu(checkAcc);
				}
				return;
			case "2":
				//User user = new User();
				
				System.out.println("  [회원가입]");
				//닉네임, 아이디 중복할 수 없음
				//둘중 하나 입력하고 중복이면 메뉴로 돌아감
				System.out.print("  아이디 입력(필수/최소 8자 최대 15자(영문, 숫자 조합으로 입력) >> ");
				String userIdJoin = scanner.nextLine();
				if(userIdJoin.length() > 15 && userIdJoin.length() < 9) {
					System.out.println("  아이디는 8자 이상, 15자 이하로 설정해주세요.");
					break;
				}
				if(userIdJoin.equals(udao.noReId(userIdJoin))) {
					System.out.println("  이미 존재하는 아이디입니다 다시 시작해주세요.");
					break;
				}
				System.out.println(); 
				
				System.out.print("  비밀번호 입력(필수/최대 15자(영문, 숫자 조합으로 입력) >> ");
				String userPwJoin = scanner.nextLine();
				if(userPwJoin.length() > 15 && userPwJoin.length() < 9) {
					System.out.println("  비밀번호는 8자 이상, 15자 이하로 설정해주세요.");
					break;
				}
				System.out.println(); 
				
				System.out.print("  실제 이름 입력(필수) >> ");
				String userNameJoin = scanner.nextLine();
				if(userNameJoin.length() > 10) {
					System.out.println("  이름이 10자 이상이신경우 고객센터로 문의 바랍니다.");
					break;
				}
				System.out.println(); 
				
				System.out.print("  닉네임 입력(필수/최대 10자) >> ");
				String nickNameJoin = scanner.nextLine();
				if(nickNameJoin.length() > 10 && nickNameJoin.length() < 2) {
					System.out.println("  닉네임은 2자 이상 10자 이하로 설정해주세요.");
					break;
				}
				if(nickNameJoin.equals(udao.noReNickname(nickNameJoin))) {
					System.out.println("  이미 존재하는 닉네임입니다 다시 시작해주세요.");
					break;
				}
				
				
				System.out.println(); 
				
				System.out.print("  전화번호 입력(필수/010xxxxxxxx의 형태로 입력) >> ");
				String userTelJoin = scanner.nextLine();
				if(userTelJoin.trim().isEmpty()) {
					System.out.println("  전화번호를 입력해주세요.\n  처음부터 다시 시작합니다.");
					break;
				}
				System.out.println(); 
				
				System.out.println("  상태메시지 입력(최대 60자/나중에 입력: 엔터) >> ");
				String stateMessage = scanner.nextLine();
				if(stateMessage.length() > 60) {
					System.out.println("  상태메시지는 최대 60자 입니다.");
				}
				System.out.println();
				
				udao.join(userIdJoin, userPwJoin, userNameJoin, nickNameJoin, userTelJoin, ("     " + stateMessage));
				
				System.out.println("  메뉴로 돌아갑니다");
				break;
			case "3":
				System.out.println("  프로그램을 종료합니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
	} //end of 로그인 메뉴
	
	//메인 메뉴
	public void mainMenu(User user) {
		int count = 0;
		while(true) {
			System.out.println("-------------------------------------------------------------------");
			System.out.println("  " + user.getNickName() + "님의 메뉴화면입니다.");
			System.out.println();
			System.out.println("  1.글쓰기 | 2.게시판 | 3.유저 검색 | 4.글 수정/삭제 | 5.메세지 | 6.프로필 | 7.종료  ");
			System.out.println("-------------------------------------------------------------------");
			System.out.print("  입력 >> ");
			String menuNum = scanner.nextLine();
			System.out.println();
			
			switch(menuNum) {
			case "1":
				System.out.println("  [글쓰기]");
				System.out.println("  자유로운 생각을 담아보세요!");
				while(true) {
					while(true) {
						System.out.print("  제목(최대 30자) >> ");
						inputTitle = scanner.nextLine();
						if(inputTitle.length() > 30) {
							System.out.println("  30자 초과입니다 다시 제목을 입력해주세요.");
							break;
						}
						count++;
						
						break;
					}
					//count가 숫자가 올라가면 30자 초과가 아닌 정상적으로 입력이 완료됐다는 의미
					if(count > 0) {
						System.out.println("  제목 입력 완료");
						System.out.println();
						break;
					}
					System.out.println();
				}
				count = 0;
				
				while(true) {					
					while(true) {					
						System.out.println("  내용은 최대 100자 입니다.(공백 포함)");
						
						//내용 입력 받는 메소드를 inputContent라는 변수로 리턴받았음.
						
						inputContent = fdao.inputContents();
						if(inputContent.length() > 100) {
							System.out.println("  100자 초과입니다 \n  내용을 다시 입력해주세요");
							break;
						}
						System.out.println();
						//공백을 입력하면 다시 시작하게 만들기.			
						if(inputTitle.trim().isEmpty() && inputContent.trim().isEmpty()) {
							System.out.println("  제목 또는 내용을 입력하세요 \n  메뉴로 돌아갑니다.");
						}
						count++;
						break;
					}
					if(count > 0) {
						System.out.println("  내용 입력 완료");
						System.out.println();
						break;
					}
					System.out.println();
				}
				
				System.out.println("  게시판에 공유하시겠습니까?\n" + "  제목: " + inputTitle);
				System.out.println("  1.공유 / 2.취소");
				menuNum = scanner.nextLine();
				if(menuNum.equals("1")) {
					fdao.insertContents(user.getNickName(), inputTitle, inputContent);
					
					break;
				} else {
					System.out.println("  메뉴로 돌아갑니다.");
					break;
				}
				
			case "2":
				//게시물 목록 출력 메뉴 불러오기
				boardMenu(user.getNickName());
				break;
			case "3":
				System.out.println("  [유저 검색]");
				searchUser(user.getNickName());
				break;
			case "4":
				System.out.println("  [글 수정]");
				updateMenu(user.getNickName());
				break;
			case "5": 
				System.out.println("  [메세지]");
				
				//구현 안됨.
				messageMenu(user.getNickName());
				break;
			case "6":
				setting(user);
				break;
			case "7":
				System.out.println("  프로그램을 종료합니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
		
	} //end of mainMenu
	
	//게시물 전체 불러오기
	public void boardMenu(String nickname) {	
		//셀렉트로 리스트 객체에 저장해서 모두 가져오기, 5개씩 출력 / 제목 닉네임 좋아요 수 표시
		//메뉴 만들어서 입력받기 1.이전 2.다음 3.게시글보기 4.게시글 검색하기 5.메뉴로 돌아가기
		//3-- 글 제목, 닉네임, 좋아요 수 \n 내용 \n 1.댓글작성하기 2.좋아요 누르기메뉴 3.친구한테 보내기 출력 \n댓글들 출력
		//4-- 1.제목 입력하기 2.작성자 닉네임 입력하기
		pageNum = 0;
		while(true) {
			System.out.println("-------------------------------------------------------------------");
			System.out.println("  [전체 게시글 목록 출력]\n");
			int lastPage = fdao.showBoardList(pageNum);
			System.out.println();
			
			System.out.println("  1.이전 | 2.다음 | 3.글보기 | 4.검색 | 5.메뉴로 돌아가기");
			System.out.println("-------------------------------------------------------------------");
			System.out.print("  입력 >>");
			String menuNum = scanner.nextLine();
			
			
			switch(menuNum) {
			case "1":
				if(pageNum != 0) {
					pageNum -= 5;
				}
				break;
			case "2":
					if(pageNum+5 < lastPage) {
						pageNum += 5;
					} else {
						pageNum += 0;
					}
				break;
			case "3":
				System.out.print("  자세히 보고싶은 게시물의 인덱스 번호 입력 >> ");
				int indexNum = Integer.parseInt(scanner.nextLine());
				//유저가 입력한 인덱스번호를 통해 게시물 고유의 번호를 찾기위한 메소드 호출
				int ownBoardNum = fdao.getBoardNumFromDb(indexNum);
				
				while(true) {
					//유저가 돌아가기를 누르면 카운트가 올라가서 while문 탈출가능
					int count = 0;
					String allComment;
					System.out.println("-------------------------------------------------------------------");
					System.out.println();
					
					System.out.println(fdao.selectContent(indexNum));
					//댓글 출력
					System.out.println();
					System.out.println("  =======댓글=======");
					allComment = fdao.commentList(ownBoardNum);
					if(allComment == null) {
						System.out.println("  댓글이 없습니다.");
					} else {
						System.out.println(allComment);
					}
					System.out.println("  =================\n");
					System.out.println("\n-------------------------------------------------------------------");
					
					//좋아요, 댓글달기 구현
					System.out.println("  1.좋아요 누르기 | 2.댓글 작성 | 3.이전으로 돌아가기");
					String likeCommentMenu = scanner.nextLine();
					
					switch(likeCommentMenu) {
					case "1":
						likeMenu(nickname, indexNum);
						
						break;
					case "2":
						System.out.println("  댓글은 최대 100자입니다.");
						System.out.println("  댓글입력 >> ");
						String comment = fdao.inputContents();
						if(comment.length() > 100) {
							System.out.println("  댓글은 최대 100자입니다");
							System.out.println("  다시 입력해주세요.");
							break;
						}
						CommentMenu(nickname, indexNum, comment);
						break;
					case "3":
						count++;
						System.out.println("  메뉴로 돌아갑니다.");
						break;
					default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
					}
					if(count == 1) {
						break;
					}
				}


				break;
			case "4":
				searchMenu(nickname);
				break;
			case "5":
				System.out.println("  메뉴로 돌아갑니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}	
		}
	}// end of boardMenu
	
	//유저 검색
	public void searchUser(String nickname) {
		//유저 이름 입력받기 리스트로 유저 이륾 모두 가져오기
		//1.자세히 보기 2.메뉴로 돌아가기
		//1을 누르면 제일 상단에는 유저 이름, 총 좋아요 수 그리고 아래로 내려가서 유저가 작성한 글들 모두 출력
		
		//유저 리스트 가져오기
		
		//1.자세히 보기 2.메뉴로 돌아가기
		while(true) {			
				System.out.println("  검색할 유저의 닉네임을 입력해주세요. ");
				System.out.println("  취소: \"CLOSE\"");
				String inputNickname = scanner.nextLine();
				if(inputNickname.equals("CLOSE")) {
					break;
				}
				User user = udao.getUser(inputNickname);
				System.out.println("--------------------------------------");
				System.out.print("닉네임: " + user.getNickName());
				System.out.println("\t총 좋아요 수: " + user.getTotalLike());
				System.out.println("\n상태메시지 >> \n" + user.getStateMessage());
				System.out.println("--------------------------------------");
				System.out.println("  게시물보기 : 아무거나 입력");
				scanner.nextLine();
				searchMenuForNick(nickname, inputNickname);
				break;
		}
	}//end of searchUser
	
	//게시물 제목으로 검색
	public void searchMenu(String nickname) {
		
		
		int pageNum = 0;
		
		System.out.println("  [글검색]");
		
		System.out.print("  제목으로 검색 >> ");
		String inputTitle = scanner.nextLine();
		while(true) {		
			System.out.println("-------------------------------------------------------------------");
			System.out.println("  제목: " + inputTitle + "\t 검색결과");
			int lastPage = fdao.showBoardListConditionforTitle(pageNum, inputTitle);
			System.out.println();
			
			System.out.println("  1.이전 | 2.다음 | 3.글보기 | 4.글 목록으로 돌아가기");
			System.out.println("-------------------------------------------------------------------");
			System.out.print("  입력 >>");
			String menuNum = scanner.nextLine();
			
			switch(menuNum) {
			case "1":
				if(pageNum > 4) {
					pageNum -= 5;
				} else {
					pageNum = 0;
				}
				break;
			case "2":
					if(pageNum+5 < lastPage) {
						pageNum += 5;
					} else {
						pageNum += 0;
					}
				break;
			case "3":
				System.out.print("  자세히 보고싶은 게시물의 인덱스 번호 입력 >> ");
				int indexNum = Integer.parseInt(scanner.nextLine());
				//유저가 입력한 인덱스번호를 통해 게시물 고유의 번호를 찾기위한 메소드 호출
				int ownBoardNum = fdao.getBoardNumFromDb(indexNum);
				
				while(true) {
					//유저가 돌아가기를 누르면 카운트가 올라가서 while문 탈출가능
					int count = 0;
					String allComment;
					System.out.println("-------------------------------------------------------------------");
					System.out.println();
					
					System.out.println(fdao.selectContentConditionForTitle(inputTitle, indexNum));
					//댓글 출력
					System.out.println();
					System.out.println("  =======댓글=======");
					allComment = fdao.commentList(ownBoardNum);
					if(allComment == null) {
						System.out.println("  댓글이 없습니다.");
					} else {
						System.out.println(allComment);
					}
					System.out.println("  ================\n");
					System.out.println("\n-------------------------------------------------------------------");
					
					//좋아요, 댓글달기 구현
					System.out.println("  1.좋아요 누르기 | 2.댓글 작성 | 3.이전으로 돌아가기");
					String likeCommentMenu = scanner.nextLine();
					
					switch(likeCommentMenu) {
					case "1":
						likeMenu(nickname, indexNum);
						
						break;
					case "2":
						System.out.println("  댓글은 최대 100자입니다.");
						System.out.println("  댓글입력 >> ");
						String comment = fdao.inputContents();
						if(comment.length() > 100) {
							System.out.println("  댓글은 최대 100자입니다");
							System.out.println("  다시 입력해주세요.");
							break;
						}
						CommentMenu(nickname, indexNum, comment);
						break;
					case "3":
						count++;
						System.out.println("  메뉴로 돌아갑니다.");
						break;
					default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
					}
					if(count == 1) {
						break;
					}
				}


				break;
			case "4":
				System.out.println("  메뉴로 돌아갑니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
	}//end of searchMenu
	
	//유저 닉네임으로 검색
	public void searchMenuForNick(String nickname, String inputNickname) {
		
		
		int pageNum = 0;
		
		while(true) {		
			System.out.println("-------------------------------------------------------------------");
			System.out.println("  " + inputNickname + "님의 게시물");
			int lastPage = fdao.showBoardListConditionForName(pageNum, inputNickname);
			System.out.println();
			
			System.out.println("  1.이전 | 2.다음 | 3.글보기 | 4.글 목록으로 돌아가기");
			System.out.println("-------------------------------------------------------------------");
			System.out.print("  입력 >>");
			String menuNum = scanner.nextLine();
			
			switch(menuNum) {
			case "1":
				if(pageNum > 4) {
					pageNum -= 5;
				} else {
					pageNum = 0;
				}
				break;
			case "2":
					if(pageNum+5 < lastPage) {
						pageNum += 5;
					} else {
						pageNum += 0;
					}
				break;
			case "3":
				System.out.print("  자세히 보고싶은 게시물의 인덱스 번호 입력 >> ");
				int indexNum = Integer.parseInt(scanner.nextLine());
				//유저가 입력한 인덱스번호를 통해 게시물 고유의 번호를 찾기위한 메소드 호출
				int ownBoardNum = fdao.getBoardNumFromDb(indexNum);
				
				while(true) {
					//유저가 돌아가기를 누르면 카운트가 올라가서 while문 탈출가능
					int count = 0;
					String allComment;
					System.out.println("-------------------------------------------------------------------");
					System.out.println();
					System.out.println(fdao.selectContentConditionForName(inputNickname, indexNum));
					//댓글 출력
					System.out.println();
					System.out.println("  =======댓글=======");
					allComment = fdao.commentList(ownBoardNum);
					if(allComment == null) {
						System.out.println("  댓글이 없습니다.");
					} else {
						System.out.println(allComment);
					}
					System.out.println("  =================\n");
					System.out.println("\n-------------------------------------------------------------------");
					
					//좋아요, 댓글달기 구현
					System.out.println("  1.좋아요 누르기 | 2.댓글 작성 | 3.이전으로 돌아가기");
					String likeCommentMenu = scanner.nextLine();
					
					switch(likeCommentMenu) {
					case "1":
						likeMenu(nickname, indexNum);
						
						break;
					case "2":
						System.out.println("  댓글은 최대 100자입니다.");
						System.out.println("  댓글입력 >> ");
						String comment = fdao.inputContents();
						if(comment.length() > 100) {
							System.out.println("  댓글은 최대 100자입니다");
							System.out.println("  다시 입력해주세요.");
							break;
						}
						CommentMenu(nickname, indexNum, comment);
						break;
					case "3":
						count++;
						System.out.println("  메뉴로 돌아갑니다.");
						break;
					default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
					}
					if(count == 1) {
						break;
					}
				}


				break;
			case "4":
				System.out.println("  메뉴로 돌아갑니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
	}//end of searchMenuForNick
	
	//본인이 작성한 글 리스트 출력
	public void updateMenu(String nickname) {
		int count = 0;
		//본인이 작성한 글들 리스트 5개씩 전체 출력
		//1.이전 2.다음 3.수정할 게시글 번호 입력하기
		//3.제목, 내용 처음부터 다시 입력
		int pageNum = 0;
		while(true) {			
			System.out.println("-------------------------------------------------------------------");
			System.out.println("  [게시글 수정]");
			System.out.println("  " + nickname + "님이 작성하신 글 리스트입니다.");
			
			int lastPage = fdao.showBoardListConditionForName(pageNum, nickname);
			System.out.println("\n  1.이전 | 2.다음 | 3.글보기 | 4.메뉴로 돌아가기 ");
			System.out.println("\n-------------------------------------------------------------------");
			System.out.print("  입력 >>");
			String menuNum = scanner.nextLine();
			System.out.println();
			switch(menuNum) {
			case "1":
				if(pageNum > 4) {
					pageNum -= 5;
				} else {
					pageNum = 0;
				}
				break;
			case "2":
					if(pageNum+5 < lastPage) {
						pageNum += 5;
					} else {
						pageNum += 0;
					}
				break;
			case "3":
				System.out.print(" 수정/삭제 할 게시물의 인덱스 번호를 눌러주세요 >> ");
				int indexNum = Integer.parseInt(scanner.nextLine());
				System.out.println("-------------------------------------------------------------------");
				System.out.println();
				
				System.out.println(fdao.selectContentConditionForName(nickname, indexNum));
				System.out.println("\n-------------------------------------------------------------------");
				System.out.println("1.수정하기 | 2.삭제하기 | 3.메뉴로 돌아가기");
				String choice3 = scanner.nextLine();
				System.out.println();
				
				switch(choice3) {
				case "1" : 
					while(true) {
						while(true) {
							System.out.print("  새로운 제목(최대 30자) >> ");
							inputTitle = scanner.nextLine();
							if(inputTitle.length() > 30) {
								System.out.println("  30자 초과입니다 다시 제목을 입력해주세요.");
								break;
							}
							count++;
							
							break;
						}
						//count가 숫자가 올라가면 30자 초과가 아닌 정상적으로 입력이 완료됐다는 의미
						if(count > 0) {
							System.out.println("  제목 입력 완료");
							System.out.println();
							break;
						}
						System.out.println();
					}
					count = 0;
					
					while(true) {					
						while(true) {					
							System.out.println("  새로운 내용 입력\n 내용은 최대 100자 입니다.(공백 포함)");
							
							//내용 입력 받는 메소드를 inputContent라는 변수로 리턴받았음.
							inputContent = fdao.inputContents();
							if(inputContent.length() > 100) {
								System.out.println("  100자 초과입니다 \n  내용을 다시 입력해주세요");
								break;
							}
							System.out.println();
							//공백을 입력하면 다시 시작하게 만들기.			
							if(inputTitle.trim().isEmpty() && inputContent.trim().isEmpty()) {
								System.out.println("  제목 또는 내용을 입력하세요 \n  메뉴로 돌아갑니다.");
							}
							count++;
							break;
						}
						if(count > 0) {
							System.out.println("  내용 입력 완료");
							System.out.println();
							break;
						}
						System.out.println();
					}
					fdao.updateContentConditionForName(nickname, indexNum, inputTitle, inputContent);
					break;
				case "2" :
					System.out.println("  정말로 삭제하시겠습니까?\n  삭제:y / 아니오:n");
					String choice2 = scanner.nextLine();
					if(choice2.equals("y") || choice2.equals("Y")) {
						fdao.delContentConditionForName(nickname, indexNum);						
					} else {
						System.out.println("이전 메뉴로 돌아갑니다.");
					}
					break;
				case "3" :
					System.out.println("이전 메뉴로 돌아갑니다.");
					break;
				default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
				}
				break;
			case "4":
				System.out.println("  메뉴로 돌아갑니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
		
		
	}//end of updateMenu
	
	//메세지 메뉴
	public void messageMenu(String nickname) {
		//전체 메세지 출력 5개씩 리스트로
		//1.이전 | 2.다음 | 3.메세지 보내기 | 4.메뉴로 돌아가기

		int pageNum = 0;
		
		while(true) {		
			System.out.println("-------------------------------------------------------------------");
			System.out.println("  ["+ nickname +"님의 메세지 내역]");
			System.out.println("  5개씩 출력됩니다.");
			int lastPage = fdao.showMessageList(pageNum, nickname);
			System.out.println();
			
			System.out.println("  1.이전 | 2.다음 | 3.메세지 보내기 | 4.메뉴로 돌아가기");
			System.out.println("-------------------------------------------------------------------");
			System.out.print("  입력 >>");
			String menuNum = scanner.nextLine();
			
			switch(menuNum) {
			case "1":
				if(pageNum > 4) {
					pageNum -= 5;
				} else {
					pageNum = 0;
				}
				break;
			case "2":
				
				if(pageNum+5 < lastPage) {
					pageNum += 5;
				} else {
					pageNum += 0;
				}
				
				break;
			case "3":
				System.out.println("  [메세지 발송]\n");
				System.out.print("  받는 사용자의 닉네임을 입력해주세요 >> ");
				String recipient = scanner.nextLine();
				if(recipient.length() > 10) {
					System.out.println("  유저 닉네임은 10자 이하입니다.");
					System.out.println("  이전메뉴로 돌아갑니다.");
					break;
				}
				if(!recipient.equals(udao.noReNickname(recipient))) {
					System.out.println("  존재하지 않는 닉네임입니다\n  이전메뉴로 돌아갑니다.");
					break;
				}
				System.out.println();
				System.out.println("  메세지는 300자 이하로 보낼수 있습니다.");
				String message = fdao.inputContents();
				if(message.length() > 300) {
					System.out.println("  메세지는 300자 이하로 보낼수 있습니다.");
					System.out.println("  이전메뉴로 돌아갑니다.");
					break;
				}
				fdao.sendMessage(nickname, recipient, message);
				break;
			case "4":
				System.out.println("  메뉴로 돌아갑니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
		
	}//end of messageMenu
	
	//개인 프로필 메뉴
	public void setting(User myAcc) {
		//출력 닉네임 / 총 좋아요 수 \n상태메시지
		//1.닉네임 수정 2.아이디 변경 3.비밀번호 변경 4.회원탈퇴
		while(true) {			
			System.out.println("-----------------------------------------------------------------------------\n");
			System.out.println("  [프로필 설정]");
			System.out.println("  " + myAcc.getNickName() + "님의 프로필입니다.");
			User user = udao.getUser(myAcc.getNickName());
			System.out.print("  닉네임: " + user.getNickName());
			System.out.println("\t총 좋아요 수: " + user.getTotalLike());
			System.out.println("  \n  상태메시지 >> \n" + user.getStateMessage());
			System.out.println("-----------------------------------------------------------------------------");
			innerSetting(myAcc);
			System.out.println("-----------------------------------------------------------------------------");
			System.out.println("  메뉴로 돌아갑니다.");
			break;
	}
		
		return;
	}//end of setting
	
	//개인 프로필 상세 설정------------------메세지 테이블 닉네임 변경 메소드 구현해야됨. 계정탈퇴하면 모든 로그들 삭제
	public void innerSetting(User myAcc) {
		String checkId;
		String checkPw;
		User user = null;
		
		while(true) {
			System.out.println("  1.닉네임 변경 | 2.상태메시지 변경 | 3.아이디 변경 | 4.비밀번호 변경 | 5.회원탈퇴 | 6.메뉴로 돌아가기");
			System.out.print("  입력 >> ");
			String menuNum = scanner.nextLine();
			System.out.println();
			switch(menuNum) {
			case "1":
				System.out.println("  [닉네임 변경]");
				System.out.print("  변경할 닉네임 입력 >> ");
				String updateNickname = scanner.nextLine();
				//닉네임 길이체크
				if(updateNickname.length() > 10 && updateNickname.length() < 2) {
					System.out.println("닉네임의 길이는 최소 2자 최대 10자입니다.");
					break;
				}
				//닉네임 중복체크
				if(updateNickname.equals(udao.noReNickname(updateNickname))) {
					System.out.println("  이미 존재하는 닉네임입니다 다시 시작해주세요.");
					break;
				}
				System.out.println();
				
				
				
				//좋아요 테이블에 있는 닉네임 이름 업데이트
				fdao.changeNickOnTblLike(myAcc.getNickName(), updateNickname);
				
				//게시물 테이블에 있는 닉네임 이름 업데이트
				fdao.changeNickOnTblBoard(myAcc.getNickName(), updateNickname);
				
				//댓글 테이블에 있는 닉네임 이름 업데이트
				fdao.changeNickOnTblComment(myAcc.getNickName(), updateNickname);
				
				//메세지 테이블에 있는 닉네임 업데이트
				fdao.changeNickOnTblMessage(myAcc.getNickName(), updateNickname);
				
				//유저 테이블에 있는 닉네임 이름 업데이트
				udao.updateNick(myAcc.getNickName(), updateNickname);
				
				//메인화면에서 사용되는 닉네임 변경하기
				myAcc.setNickName(updateNickname);
				
//				System.out.println("  프로그램을 종료합니다.");
//				System.exit(0);
				return;
			case "2":
				System.out.println("  [상태메시지 변경]");
				System.out.print("  입력(최대 60자) >> ");
				String newStateMessage = fdao.inputContents();
				System.out.println();
				
				udao.updateState(myAcc.getNickName(), newStateMessage);
				break;
			case "3":
				System.out.println("  [아이디 변경]\n");
				
				System.out.println("  아이디, 비밀번호를 확인하겠습니다.");
				System.out.print("  아이디 입력 >> ");
				checkId = scanner.nextLine();
				System.out.println();
				
				System.out.print("  비밀번호 입력 >> ");
				checkPw = scanner.nextLine();
				System.out.println();
				
				user = udao.login(checkId, checkPw);
				if(user != null) {
					System.out.println("  새로운 아이디를 입력해주세요");
					String newId = scanner.nextLine();
					//아이디 변경 중복 체크
					if(newId.equals(udao.noReId(newId))) {
						System.out.println("  이미 존재하는 아이디입니다 다시 시작해주세요.");
						break;
					}
					
					//변경된 아이디로 업데이트
					udao.updateId(checkId, checkPw, newId);
				}
				break;
			case "4":
				System.out.println("  [비밀번호 변경]\n");
				
				System.out.println("  아이디, 비밀번호를 확인하겠습니다.");
				System.out.print("  아이디 입력 >> ");
				checkId = scanner.nextLine();
				System.out.println();
				
				System.out.print("  비밀번호 입력 >> ");
				checkPw = scanner.nextLine();
				System.out.println();
				
				user = udao.login(checkId, checkPw);
				if(user != null) {
					System.out.println("  새로운 비밀번호를 입력해주세요");
					String newPw = scanner.nextLine();
					udao.updatePw(checkId, checkPw, newPw);
					
				} else {
					System.out.println("오류");
					break;
				}
				break;
			case "5":
				System.out.println("  [회원탈퇴]\n");
				
				System.out.println("  아이디, 비밀번호를 확인하겠습니다.");
				System.out.print("  아이디 입력 >> ");
				checkId = scanner.nextLine();
				System.out.println();
				
				System.out.print("  비밀번호 입력 >> ");
				checkPw = scanner.nextLine();
				System.out.println();
				
				user = udao.login(checkId, checkPw);
				if(user != null) {
					System.out.println("  ※삭제후 계정을 복구할 수 없습니다※");
					System.out.print("  삭제: y / 취소: n");
					String deleteCheck = scanner.nextLine();
					System.out.println();
					if(deleteCheck.equals("y")) {
						
						
						System.out.println("  지금까지 freeboard를 이용해주셔서 감사합니다\n  " + myAcc.getNickName() + "님의 앞으로의 삶이 평안하시길 바랍니다.");
						//계정 삭제 메소드
						udao.delUser(checkId, checkPw);
						//모든 로그를 삭제하는 메소드 필요함
						fdao.delAllOfLog(myAcc.getNickName());
						
						//프로그램 종료 메소드
						System.exit(0);
					} else {
						System.out.println("  이전 메뉴로 돌아갑니다.");
						break;
					}
				}
				
				break;
			case "6":
				System.out.println("  이전 메뉴로 돌아갑니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			
			}
		}
	}//end of innerSetting
	
	//좋아요 설정 메소드
	public void likeMenu(String nickname, int indexNum) {
		//게시물 고유 번호를 가져왔음.
		int ownBoardNum = fdao.getBoardNumFromDb(indexNum);
		
		
		//만약 이미 좋아요를 눌렀다면 "이미 좋아요를 눌렀습니다 출력"
		String forNoReLike = fdao.noReLike(ownBoardNum, nickname);
		if(!forNoReLike.equals(nickname)) {
			
			//좋아요 테이블에 게시물 고유 번호와 좋아요를 누른사람의 닉네임을 넣음.
			fdao.insertLike(ownBoardNum, nickname);
			
			//게시물 테이블의 likeNum칼럼의 좋아요 수 업데이트
			fdao.updateLikeNum(ownBoardNum);
			
			//게시판 테이블의 모든 좋아요수를 더해서 리턴
			int sumOfLike = udao.sumOfLike(nickname);
			
			//유저 테이블의 total_like칼럼의 좋아요 수 업데이트
			udao.updateTotalLike(nickname, sumOfLike);
		} else {			
			System.out.println("  좋아요는 게시물당 한번만 보낼 수 있습니다.");
			System.out.println("  이전 화면으로 돌아갑니다.");
			return;
		}
		 
	}
	
	//댓글 입력 메소드
	public void CommentMenu(String nickname, int indexNum, String comment) {
		//게시물의 고유번호 가져오기
		int ownBoardNum = fdao.getBoardNumFromDb(indexNum);
		
		//고유번호에 댓글 넣기
		fdao.insertComment(ownBoardNum, nickname, comment);
		
	}
}
