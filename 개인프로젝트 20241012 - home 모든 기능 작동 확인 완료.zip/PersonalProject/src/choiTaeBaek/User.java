package choiTaeBaek;

public class User {
	//유저정보

	private String userPrimaryNum;
	private String userId;
	private String userPw;
	private String nickName;
	private String userName;
	private String userGrant;
	private String userBirth;
	private String userTel;
	private String userEmail;
	private String stateMessage;
	private int totalLike;
	
	
	//method
	public String getStateMessage() {return stateMessage;}
	public void setStateMessage(String stateMessage) {this.stateMessage = stateMessage;}
	public String getUserPrimaryNum() {return userPrimaryNum;}
	public void setUserPrimaryNum(String userPrimaryNum) {this.userPrimaryNum = userPrimaryNum;}
	public String getUserId() {return userId;}
	public void setUserId(String userId) {this.userId = userId;}
	public String getUserPw() {return userPw;}
	public void setUserPw(String userPw) {this.userPw = userPw;}
	public String getUserGrant() {return userGrant;}
	public void setUserGrant(String userGrant) {this.userGrant = userGrant;}
	public String getNickName() {return nickName;}
	public void setNickName(String nickName) {this.nickName = nickName;}
	public String getUserName() {return userName;}
	public void setUserName(String userName) {this.userName = userName;}
	public String getUserBirth() {return userBirth;}
	public void setUserBirth(String userBirth) {this.userBirth = userBirth;}
	public String getUserTel() {return userTel;}
	public void setUserTel(String userTel) {this.userTel = userTel;}
	public String getUserEmail() {return userEmail;}
	public void setUserEmail(String userEmail) {this.userEmail = userEmail;}
	public int getTotalLike() {return totalLike;}
	public void setTotalLike(int totalLike) {this.totalLike = totalLike;}
}
