package choiTaeBaek;

public class Comment {
	private String nickname;
	private String colComment;
	private int boardNum;
	private String commentDate;
	
	
	public String getNickname() {return nickname;}
	public void setNickname(String nickname) {this.nickname = nickname;}
	public String getColComment() {return colComment;}
	public void setColComment(String colComment) {this.colComment = colComment;}
	public int getBoardNum() {return boardNum;}
	public void setBoardNum(int boardNum) {this.boardNum = boardNum;}
	public String getCommentDate() {return commentDate;}
	public void setCommentDate(String commentDate) {this.commentDate = commentDate;}
}
