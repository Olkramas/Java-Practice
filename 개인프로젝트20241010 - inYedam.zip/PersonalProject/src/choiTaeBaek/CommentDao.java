package choiTaeBaek;

public class CommentDao {

}
