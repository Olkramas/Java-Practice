package choiTaeBaek;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FreeBoardDao extends DAO{
	Scanner scanner = new Scanner(System.in);
	

	
	public String inputContents() {
		String result = "내용 > ";
		int count = 0;
		
		System.out.println("  입력을 시작합니다\n  입력 종료를 원하시면 \"CLOSE\"를 입력하세요");
		System.out.println();
		System.out.print("내용입력 >> ");
		
		while(true) {
			String input = scanner.nextLine();
			
			if(input.equals("CLOSE")) {
				System.out.println("  입력을 종료합니다.");
				break;
			}
			
			count++;
			if(count == 1) {
				result += input + "\n";
			} else {
				result += "     " + input + "\n";
			}
		}
		return result;
	}
	public int showBoardList(int pageNum) {
		//어레이 리스트 선언
		List<FreeBoard> boardList = new ArrayList<>();
		
		//모든 게시글 리스트 boardList에 저장
		boardList = selectAll();
		
		//모든 게시글 리스트의 리스트 사이즈 구하기(db에서 count)
		int lastPage = totalListSize();
		
		
		if(lastPage < pageNum) {
			pageNum = lastPage-5;
		}
		System.out.println("   No\t작성자\t제목\t\t좋아요");
		for(int i=pageNum; i<pageNum+5 && i<totalListSize(); i++ ) {
			System.out.println("  [" + (i + 1) + "]\t" + boardList.get(i).getNickName() + "\t" + boardList.get(i).getTitle()
					+ "\t\t" + boardList.get(i).getLikeNum() + "\t" + boardList.get(i).getWriteDate()); 
		}
		
		return lastPage;
		//5행씩 출력하기
	}
	
	//제목으로 검색하기 리스트의 사이즈 리턴
	public int showBoardListCondition(int pageNum, String inputTitle) {
		List<FreeBoard> boardList = selectCondition(inputTitle);
		int lastPage = totalListSizeCondition(inputTitle);
		
		if(lastPage < pageNum) {
			pageNum = lastPage-5;
		}
		
		System.out.println("  작성자\t제목\t\t\t\t좋아요");
		for(int i=pageNum; i<pageNum+5 && i<lastPage; i++ ) {
			System.out.println("  [" + (i + 1) + "]\t" + boardList.get(i).getNickName() + "\t" + boardList.get(i).getTitle()
					+ "\t\t" + boardList.get(i).getLikeNum() + "\t" + boardList.get(i).getWriteDate()); 
		}
		
		return lastPage;
	}
	
	//닉네임으로 검색하기 본인 게시글 수정용, 유저 검색 후 게시물 출력용
	public int showBoardListConditionForName(int pageNum, String nickname) {
		List<FreeBoard> boardList = selectConditionForName(nickname);
		int lastPage = totalListSizeConditionForName(nickname);
		
		if(lastPage < pageNum) {
			pageNum = lastPage-5;
		}
		
		System.out.println("  작성자\t제목\t\t\t\t좋아요");
		for(int i=pageNum; i<pageNum+5 && i<lastPage; i++ ) {
			System.out.println("  [" + (i + 1) + "]\t" + boardList.get(i).getNickName() + "\t" + boardList.get(i).getTitle()
					+ "\t\t" + boardList.get(i).getLikeNum() + "\t" + boardList.get(i).getWriteDate()); 
		}
		
		return lastPage;
	}
	
	//리스트의 사이즈 반환
	public int totalListSize() {
		String sql = "select count(1) "
				+ "   from   tbl_freeboard ";
		
		int listSize = 0;
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listSize = rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			return listSize;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		return listSize;
	}
	
	//리스트의 사이즈 반환(제목 조건에 맞는것들)
	public int totalListSizeCondition(String title) {
		String sql = "select count(1) "
				+ "   from   tbl_freeboard "
				+ "   where  title like ?";
		
		int listSize = 0;
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, (title+"%"));
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listSize = rs.getInt(1);
			}
			pstmt.close();
			rs.close();
			return listSize;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		return listSize;
	}
	
	public int totalListSizeConditionForName (String nickname) {
		String sql = "select count(1) "
				+ "   from   tbl_freeboard "
				+ "   where  nickname like ?";
		
		int listSize = 0;
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listSize = rs.getInt(1);
			}
			pstmt.close();
			rs.close();
			return listSize;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		return listSize;
	}
	
	
	//제목으로 찾기
	public List<FreeBoard> selectCondition(String inputTitle) {
		List<FreeBoard> boardList = new ArrayList<>();
		String sql = "select   nickname, "
				+ "            title,"
				+ "            col_content, "
				+ "            likenum,"
				+ "            write_date,"
				+ "            boardNum "
				+ "   from     tbl_freeboard "
				+ "   where    title like ? "
				+ "   order by write_date desc ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, (inputTitle + '%'));
			rs = pstmt.executeQuery();
			while(rs.next()) {
				FreeBoard board = new FreeBoard();
				board.setNickName(rs.getString(1));
				board.setTitle(rs.getString(2));
				board.setContent(rs.getString(3));
				board.setLikeNum(rs.getInt(4));
				board.setWriteDate(rs.getString(5));
				board.setBoardNum(rs.getInt(6));
				boardList.add(board);
			}
			pstmt.close();
			rs.close();
			return boardList;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return boardList;
	}
	
	//닉네임으로 찾기
	public List<FreeBoard> selectConditionForName(String nickname) {
		List<FreeBoard> boardList = new ArrayList<>();
		String sql = "select   nickname, "
				+ "            title,"
				+ "            col_content, "
				+ "            likenum,"
				+ "            write_date,"
				+ "            boardNum "
				+ "   from     tbl_freeboard "
				+ "   where    nickname = ? "
				+ "   order by write_date desc ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				FreeBoard board = new FreeBoard();
				board.setNickName(rs.getString(1));
				board.setTitle(rs.getString(2));
				board.setContent(rs.getString(3));
				board.setLikeNum(rs.getInt(4));
				board.setWriteDate(rs.getString(5));
				board.setBoardNum(rs.getInt(6));
				boardList.add(board);
			}
			pstmt.close();
			rs.close();
			return boardList;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return boardList;
	}
	
	public List<FreeBoard> selectAll() {
		List<FreeBoard> boardList = new ArrayList<>();
		String sql = "select   nickname, "
				+ "            title,"
				+ "            col_content, "
				+ "            likenum,"
				+ "            write_date,"
				+ "            boardNum "
				+ "   from     tbl_freeboard"
				+ "   order by write_date desc ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				FreeBoard board = new FreeBoard();
				board.setNickName(rs.getString(1));
				board.setTitle(rs.getString(2));
				board.setContent(rs.getString(3));
				board.setLikeNum(rs.getInt(4));
				board.setWriteDate(rs.getString(5));
				board.setBoardNum(rs.getInt(6));
				boardList.add(board);
			}
			pstmt.close();
			rs.close();
			return boardList;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return boardList;
	}
	
	public void insertContents(String nickname, String inputTitle, String inputContent) {
		String sql = "insert into tbl_freeboard ("
				+ "          nickname, "
				+ "          title, "
				+ "          col_content, "
				+ "          boardnum ) "
				+ "   values ( ?,"
				+ "            ?, "
				+ "            ?,"
				+ "            board_num.nextval ) ";
		
		
		try {
			conn = getOpen();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.setString(2, inputTitle);
			pstmt.setString(3, inputContent);
			
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  게시글을 업로드했습니다.");
			} else {
				System.out.println("  게시글 업로드를 실패했습니다 \n고객센터로 문의 부탁드립니다.");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	//유저가 인덱스 번호를 선택하면 그에 맞는 정보들을 가져옴(게시물 전체 목록)
	public String selectContent(int indexNum) {
		
		//전체 게시글 목록 boardList에 저장
		List<FreeBoard> boardList = selectAll();
		
		//유저가 입력한 인덱스 번호를 원래대로 바꿔서(입력받을때 +1상태임) 해당 board객체를 저장
		FreeBoard board = boardList.get(indexNum - 1);
		
		//하나씩 출력
		System.out.println("  작성자\t제목\t좋아요");
		return "  " + board.getNickName() + "\t" + board.getTitle() + "\t" + board.getLikeNum() + "\t" + board.getWriteDate() 
					+ "\t\n\n내용 >> \n" + board.getContent(); 
	}
	
	//유저가 인덱스 번호를 선택하면 그에 맞는 정보들을 가져옴(게시물 제목으로 찾기 목록)
	public String selectContentCondition(String title, int indexNum) {
		List<FreeBoard> boardList = selectCondition(title);
		
		FreeBoard board = boardList.get(indexNum - 1);
		
		System.out.println("  작성자\t제목\t\t좋아요");
		return "  " + board.getNickName() + "\t" + board.getTitle() + "\t\t" + board.getLikeNum() + "\t" + board.getWriteDate() 
		+ "\t\n\n내용 >> \n" + board.getContent(); 
	}
	
	//유저가 인덱스 번호를 선택하면 그에 맞는 정보들을 가져옴(작성자 이름으로 찾기 목록)
	public String selectContentConditionForName(String nickname, int indexNum) {
		List<FreeBoard> boardList = selectConditionForName(nickname);
		
		FreeBoard board = boardList.get(indexNum - 1);
		
		System.out.println("  작성자\t제목\t\t좋아요");
		return "  " + board.getNickName() + "\t" + board.getTitle() + "\t\t" + board.getLikeNum() + "\t" + board.getWriteDate() 
		+ "\t\n\n내용 >> \n" + board.getContent(); 
	}
	
	//본인 게시물 업데이트 메소드
	public void updateContentConditionForName(String nickname, int indexNum, String AftTitle, String AftContent) {
		List<FreeBoard> boardList = selectConditionForName(nickname);
		
		FreeBoard board = boardList.get(indexNum - 1);
		
		
		String sql = "update tbl_freeboard "
				+ "   set    title=?, "
				+ "          col_content=?"
				+ "   where  title=? "
				+ "   and    col_content=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, AftTitle);
			pstmt.setString(2, AftContent);
			pstmt.setString(3, board.getTitle());
			pstmt.setString(4, board.getContent());
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  \"수정 성공\"");
			} else {
				System.out.println("  \"수정 실패\"");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	//게시글 삭제 메소드
	public void delContentConditionForName(String nickname, int indexNum) {
		List<FreeBoard> boardList = selectConditionForName(nickname);
		
		FreeBoard board = boardList.get(indexNum - 1);
		
		String sql = "delete from    tbl_freeboard "
				+ "   where   title=? "
				+ "   and     col_content=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getContent());
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  \"삭제 성공\"");
			} else {
				System.out.println("  \"삭제 실패\"");
			}
			pstmt.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
				
	}

}
