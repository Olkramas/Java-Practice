package choiTaeBaek;

import java.sql.SQLException;

public class UserDao extends DAO{
	
	public User login(String userId, String userPw) {
		String sql = "select  user_id, "
					+ "       nickname "
					+ "from   tbl_user "
					+ "where  user_id=? "
					+ "and    user_pw=? ";
		
		try {
			conn = getOpen();
			

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setNickName(rs.getString(2));
				user.setUserId(rs.getString(1));
				return user;
			}
			rs.close();
			pstmt.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return null;
	}
	
	public void join(String userId, String userPw, String name, String nickName, String tel, String stateMessage) {
		String sql = "insert into tbl_user ( "
				+ "          user_id, "
				+ "          user_pw, "
				+ "          nickname, "
				+ "          user_name, "
				+ "          user_tel,"
				+ "          state_message ) "
				+ "   values( "
				+ "          ?, "
				+ "          ?, "
				+ "          ?, "
				+ "          ?, "
				+ "          ?,"
				+ "			 ? ) ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			pstmt.setString(3, nickName);
			pstmt.setString(4, name);
			pstmt.setString(5, tel);
			pstmt.setString(6, stateMessage);
			int rows = pstmt.executeUpdate();
			
			if(rows > 0) {
				System.out.println("  회원가입 성공!");
			} else {
				System.out.println("  회원가입 실패\n  문의전화 010-xxxx-xxxx");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	} //end of join method
	
	public User getUser(String nickname) {
		User user = new User();
		String sql = "select nickname, "
				+ "          total_like,"
				+ "          state_message,"
				+ "          user_id "
				+ "   from   tbl_user "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user.setNickName(rs.getString(1));
				user.setTotalLike(rs.getInt(2));
				user.setStateMessage(rs.getString(3));
			} else {
				System.out.println("존재하지 않는 닉네임입니다.");
			}
			rs.close();
			pstmt.close();
			return user;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user;
	}
	public User getUserForJoin(String id) {
		User user = new User();
		String sql = "select count(1) "
				+ "   from   tbl_user ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user.setNickName(rs.getString(1));
				user.setTotalLike(rs.getInt(2));
				user.setStateMessage(rs.getString(3));
			} else {
				System.out.println("존재하지 않는 닉네임입니다.");
			}
			rs.close();
			pstmt.close();
			return user;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user;
	}
	
	public void updateNick(String OrignalNickname, String updateNickname) {
		String sql = "update tbl_user "
				+ "   set    nickname=? "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, updateNickname);
			pstmt.setString(2, OrignalNickname);
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  닉네임 변경 성공");
				System.out.println("  변경된 닉네임은 재접속후에 사용가능합니다.");
				//성공 했을 경우에 댓글 작성자, 좋아요 누른 닉네임 모두 변경된 닉네임으로 업데이트 해야됨.
				//제일 마지막에 확인하기 그 전까지 닉네임 바꾸는 기능은 미완성
			} else {
				System.out.println("  닉네임 변경 실패");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}//end of updateNick
	
	public void updateState(String nickname, String updateState) {
		String sql = "update tbl_user "
				+ "   set    state_message=? "
				+ "   where  nickname=? ";
		여기부터 하기
	}
	
}
