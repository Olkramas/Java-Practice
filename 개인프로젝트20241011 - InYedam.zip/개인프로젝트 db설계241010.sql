--tbl_user���̺� ����
create table tbl_user (
                        user_id          varchar2(15) not null,
                        user_pw          varchar2(15) not null,
                        nickname        varchar2(10 char) not null,
                        user_name        varchar2(10 char) not null,
                        user_grant       varchar2(10) default 'User',
                        user_birth       date,
                        user_tel         varchar2(14 char) not null,
                        userEmail        varchar2(15),
                        total_like       number(38),
                        state_message    varchar2(60 char) default ' '
                        );
select *
from   tbl_user;

--�⺻Ű �����ϱ�    
--ALTER TABLE tbl_user
--ADD CONSTRAINT fk_nickname PRIMARY KEY (nickname);

--tbl_freeboard ���̺� ����
create table tbl_freeboard (
                         nickname         varchar2(10 CHAR) not null,
                         boardNum         number(38),
                         title            varchar2(30 char),
                         col_content      varchar2(100 char),
                         likeNum          number(38) default 0,
                         write_date       date default sysdate);

alter table tbl_freeboard
modify title varchar2(30 char);
desc tbl_;

select *
from   tbl_freeboard;

--��� ���̺� �����
create table tbl_comment (nickname varchar2(10 char) not null,
                          col_comment  varchar2(100),
                          boardnum number(38),
                          comment_date date default sysdate);               

--�޼��� ���̺� �����
create table tbl_message (
       nickname varchar2(10 char) not null,
       recipient varchar2 (10) not null,
       col_message varchar2 (300) not null,
       send_date date default sysdate);
       

--���ƿ� ���̺� �����
create table tbl_like ( boardNum number(38) not null,
                        nickname varchar2(10) not null );
                        
--���� ������ȣ ������ �����
--CREATE SEQUENCE user_num_sqe
--                INCREMENT BY 1
--                START WITH 1
--                MAXVALUE 9999
--                NOCACHE
--                NOCYCLE;


--�Խù� ������ȣ ������ �����
create sequence board_num_seq
                increment by 1
                start with 1
                maxvalue 9999
                nocache
                nocycle;     

select *
from   tbl_freeboard;

select *
from   tbl_like;

--�������� �ִ� ���̺��� ������
DROP TABLE tbl_comment CASCADE CONSTRAINTS;
--�������� ����
ALTER TABLE freeboard
DROP CONSTRAINT foreign_key_constraint_name;

--�������� ��κ���
SELECT constraint_name,
       column_name
FROM   user_cons_columns;  

--���� ������ �ֱ�
insert into tbl_user (
                        user_id,
                        user_pw,
                        nick_name,
                        user_name,
                        user_birth,
                        user_tel,
                        total_like )
values (
        'testid3',
        'testpw3',
        'nicktest3',
        'user3',
        '2001/11/10',
        '010-2000-3000',
        100);

--�α��θ޴� ȸ������ ����
insert into tbl_user (
            user_id,
            user_pw,
            nickname,
            user_name,
            user_tel)
values(
       'adsf6839',
       'asdf6839',
       '�¹�',
       '���¹�',
       '010-2944-7171');

select *
from   freeboard;


--�Խ��� ���̺��� ������ �ֱ�
insert into tbl_freeboard (nickname,
                       boardNum,
                       title,
                       col_content)
values      ('�¹�',
             board_num_seq.nextval,
             'test9',
             'test9'
             );
commit;
select *
from   tbl_freeboard
where  title LIKE '����%';
delete freeboard
where  user_primary_num = 7;
select *
from   tbl_freeboard;

select *
from   tbl_freeboard
order by wirte_date desc;

rollback;
commit;

select      nickname,
            title,
            col_content, 
            likenum,
            write_date,
            boardNum 
from        tbl_freeboard 
where       title like 'test%'
order by    write_date desc ;

update tbl_freeboard 
set    likeNum = (select count(1) 
                  from   tbl_like 
                  where  boardnum=1) 
where  boardnum=1;