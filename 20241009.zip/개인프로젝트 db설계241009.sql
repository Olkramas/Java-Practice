--tbl_user���̺� ����
create table tbl_user (
                        user_id          varchar2(15) not null,
                        user_pw          varchar2(15) not null,
                        nickname        varchar2(10) not null primary key,
                        user_name        varchar2(10) not null,
                        user_grant       varchar2(10) default 'User',
                        user_birth       date,
                        user_tel         varchar2(14) not null,
                        userEmail        varchar2(15),
                        total_like       number(38),
                        state_message    varchar2(60)
                        );
--�⺻Ű �����ϱ�    
--ALTER TABLE tbl_user
--ADD CONSTRAINT fk_nickname PRIMARY KEY (nickname);

--tbl_freeboard ���̺� ����
create table tbl_freeboard (
                         nickname         varchar2(10) not null,
                         boardNum         number(38) primary key,
                         title            varchar2(30),
                         col_content          varchar2(100),
                         likeNum          number(38) default 0,
                         write_date       date default sysdate);
--�÷� �̸� ����
alter table tbl_freeboard
rename column wirte_date to write_date;

--�ܷ�Ű �����ϱ�
ALTER TABLE tbl_freeboard
ADD FOREIGN KEY(nickname) REFERENCES tbl_user(nickname);

--��� ���̺� �����
create table tbl_comment (nickname varchar2(10) not null,
                          col_comment  varchar2(100),
                          boardnum number(38),
                          comment_date date default sysdate);               
                          
alter table tbl_comment
add foreign key (nickname) references tbl_user(nickname);

alter table tbl_comment
add foreign key (boardnum) references tbl_freeboard(boardnum);

--�޼��� ���̺� �����
create table tbl_message (
       nickname varchar2(10) not null,
       recipient varchar2 (10) not null,
       col_message varchar2 (300) not null,
       send_date date default sysdate);
       
alter table tbl_message
add foreign key (nickname) references tbl_user (nickname);

alter table tbl_message
add foreign key (recipient) references tbl_user (nickname);

--���� ������ȣ ������ �����
--CREATE SEQUENCE user_num_sqe
--                INCREMENT BY 1
--                START WITH 1
--                MAXVALUE 9999
--                NOCACHE
--                NOCYCLE;

--�Խù� ������ȣ ������ �����
create sequence board_num_seq
                increment by 1
                start with 1
                maxvalue 9999
                nocache
                nocycle;     





--�������� �ִ� ���̺��� ������
DROP TABLE freeboard CASCADE CONSTRAINTS;

--�������� ����
ALTER TABLE freeboard
DROP CONSTRAINT foreign_key_constraint_name;

--�������� ��κ���
SELECT constraint_name,
       column_name
FROM   user_cons_columns;  

--���� ������ �ֱ�
insert into tbl_user (
                        user_id,
                        user_pw,
                        nick_name,
                        user_name,
                        user_birth,
                        user_tel,
                        total_like )
values (
        'testid3',
        'testpw3',
        'nicktest3',
        'user3',
        '2001/11/10',
        '010-2000-3000',
        100);

--�α��θ޴� ȸ������ ����
insert into tbl_user (
            user_primary_num,
            user_id,
            user_pw,
            nick_name,
            user_name,
            user_tel)
values(user_num_sqe.nextval,
       'adsf',
       '1234',
       '�¹�',
       '���¹�',
       '102');

select *
from   freeboard;

--�Խ��� ���̺��� ������ �ֱ�
insert into tbl_freeboard (nickname,
                       boardNum,
                       title,
                       col_content)
values      ('�¹�',
             board_num_seq.nextval,
             'test title10',
             'test content10'
             );
commit;
delete freeboard
where  user_primary_num = 7;
select *
from   tbl_freeboard;

select *
from   tbl_freeboard
order by wirte_date desc;

rollback;
commit;