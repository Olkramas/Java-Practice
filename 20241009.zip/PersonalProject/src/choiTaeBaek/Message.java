package choiTaeBaek;

public class Message {
	String nickname;
	String recipient;
	String col_message;
	String send_date;
}
