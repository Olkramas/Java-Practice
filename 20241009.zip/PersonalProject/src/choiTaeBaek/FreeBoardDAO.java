package choiTaeBaek;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FreeBoardDAO extends DAO{
	Scanner scanner = new Scanner(System.in);
	List<FreeBoard> boardList = new ArrayList<>();

	
	public String inputContents() {
		String result = "내용 > ";
		int count = 0;
		
		System.out.println("  입력을 시작합니다\n  입력 종료를 원하시면 \"CLOSE\"를 입력하세요");
		System.out.println();
		System.out.print("내용입력 >>");
		
		while(true) {
			String input = scanner.nextLine();
			
			if(input.equals("CLOSE")) {
				System.out.println("  입력을 종료합니다.");
				break;
			}
			
			count++;
			if(count == 1) {
				result += input + "\n";
			} else {
				result += "     " + input + "\n";
			}
		}
		return result;
	}
	public int showBoardList(int pageNum) {
		boardList = selectAll();
		int lastPage = totalListSize();
		
		if(lastPage < pageNum) {
			pageNum = lastPage-5;
		}
		System.out.println("   No\t작성자\t제목\t\t\t좋아요");
		for(int i=pageNum; i<pageNum+5; i++ ) {
			System.out.println("  [" + (i + 1) + "]\t" + boardList.get(i).getNickName() + "\t" + boardList.get(i).getTitle()
					+ "\t\t" + boardList.get(i).getLikeNum() + "\t" + boardList.get(i).getWriteDate()); 
		}
		
		return lastPage;
	}
	
	public int totalListSize() {
		String sql = "select count(1) "
				+ "   from   tbl_freeboard ";
		
		int listSize = 0;
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listSize = rs.getInt(1);
			}
			
			return listSize;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		return listSize;
	}
	
	public List<FreeBoard> selectAll() {

		String sql = "select   nickname, "
				+ "            title,"
				+ "            col_content, "
				+ "            likenum,"
				+ "            write_date "
				+ "   from     tbl_freeboard"
				+ "   order by write_date desc ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				FreeBoard board = new FreeBoard();
				board.setNickName(rs.getString(1));
				board.setTitle(rs.getString(2));
				board.setContent(rs.getString(3));
				board.setLikeNum(rs.getInt(4));
				board.setWriteDate(rs.getString(5));
				boardList.add(board);
			}
			pstmt.close();
			rs.close();
			return boardList;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return boardList;
	}
	
	public void insertContents(String nickname, String inputTitle, String inputContent) {
		String sql = "insert into tbl_freeboard ("
				+ "          nickname, "
				+ "          title, "
				+ "          col_content, "
				+ "          boardnum ) "
				+ "   values ( ?,"
				+ "            ?, "
				+ "            ?,"
				+ "            board_num.nextval ) ";
		
		
		try {
			conn = getOpen();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			pstmt.setString(2, inputTitle);
			pstmt.setString(3, inputContent);
			
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  게시글을 업로드했습니다.");
			} else {
				System.out.println("  게시글 업로드를 실패했습니다 \n고객센터로 문의 부탁드립니다.");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
