package choiTaeBaek;

public class FreeBoard {
	
	private String userPrimaryNum;
	private String boardNum;
	private String title;
	private String content;
	private String nickName;
	private int likeNum;
	private String writeDate;
	
	//method
	@Override
	public String toString() {
		return "";
	}
	public String getWriteDate() {return writeDate;}
	public void setWriteDate(String writeDate) {this.writeDate = writeDate;}
	public String getBoardNum() {return boardNum;}
	public void setBoardNum(String boardNum) {this.boardNum = boardNum;}
	public String getTitle() {return title;}
	public void setTitle(String title) {this.title = title;}
	public String getNickName() {return nickName;}
	public void setNickName(String nickName) {this.nickName = nickName;}
	public String getContent() {return content;}
	public void setContent(String content) {this.content = content;}
	public int getLikeNum() {return likeNum;}
	public void setLikeNum(int likeNum) {this.likeNum = likeNum;}
	public String getUserPrimaryNum() {return userPrimaryNum;}
	public void setUserPrimaryNum(String userPrimaryNum) {this.userPrimaryNum = userPrimaryNum;}
}
