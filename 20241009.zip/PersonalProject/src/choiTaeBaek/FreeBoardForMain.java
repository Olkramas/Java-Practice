package choiTaeBaek;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FreeBoardForMain {
	Scanner scanner = new Scanner(System.in);
	UserDao udao = new UserDao();
	FreeBoardDAO fdao = new FreeBoardDAO();
	
	List<FreeBoard> boardList = new ArrayList<>();
	
	String menuNum;
	//while문 탈출용으로 사용.
	int count = 0;
	//페이지 넘길때 사용
	int pageNum;
	//마지막 페이지 얼마인지 확인용
	int lastPageNum;
	
	String inputTitle;
	String inputContent;
	
	
	
	public void start() {
		System.out.println("====FreeBoard에 오신것을 환영합니다====\n");
		System.out.println("  \"FreeBoard\"는 여러분들의 자유로운 "
				+ "  \n생각들을 담아내기 위해 만들어진 프로그램입니다:) \n\n");
		while(true) {
			System.out.println("================================");
			System.out.println("   1.로그인 | 2.회원가입 | 3.종료"); 
			System.out.println("================================");
			System.out.print("   입력 >> ");
			menuNum = scanner.nextLine();
			System.out.println();
			
			switch(menuNum) {
			case "1":
				System.out.println("  [로그인]");
				//로그인 구현하기
				System.out.print("  아이디 >> ");
				String userId = scanner.nextLine();
				System.out.println(); 
				
				System.out.print("  비밀번호 >> ");
				String userPw = scanner.nextLine();
				System.out.println(); 
				
				//조건 만들어서 로그인 성공하면 menu()메소드 호출하기
				User checkAcc = udao.login(userId.trim(), userPw.trim());

				if(checkAcc == null) {
					System.out.println("  아이디 비밀번호가 정확하지 않습니다.");
					break;
				} else if(checkAcc.getUserId().equals(userId)) {
					System.out.println("  환영합니다 " + checkAcc.getNickName() + "님");
					mainMenu(checkAcc.getNickName());
				}
				return;
			case "2":
				System.out.println("  [회원가입]");
				//닉네임, 아이디 중복할 수 없음
				//둘중 하나 입력하고 중복이면 메뉴로 돌아감
				System.out.print("  아이디 입력 >> ");
				String userIdJoin = scanner.nextLine();
				System.out.println(); 
				
				System.out.print("  비밀번호 입력 >> ");
				String userPwJoin = scanner.nextLine();
				System.out.println(); 
				
				System.out.print("  이름 입력 >> ");
				String userNameJoin = scanner.nextLine();
				System.out.println(); 
				
				System.out.print("  닉네임 입력 >> ");
				String nickNameJoin = scanner.nextLine();
				System.out.println(); 
				
				System.out.print("  전화번호 입력 >> ");
				String userTelJoin = scanner.nextLine();
				System.out.println(); 
				
				
				udao.join(userIdJoin, userPwJoin, userNameJoin, nickNameJoin, userTelJoin);
				
				System.out.println("  메뉴로 돌아갑니다");
				break;
			case "3":
				System.out.println("  프로그램을 종료합니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
	} //end of 로그인 메뉴
	
	//로그인 메뉴에서 닉네임을 받아옴 그걸로 프로필을 갔을 때 고격정보를 확인할 수 있게 만들거임.
	public void mainMenu(String nickname) {
		while(true) {
			System.out.println("----------------------------------------------------------------");
			System.out.println("  " + nickname + "님의 메뉴화면입니다.");
			System.out.println();
			System.out.println("  1.글쓰기 | 2.게시판 | 3.유저 검색 | 4.글 수정 | 5.프로필 수정 | 6.종료  ");
			System.out.println("----------------------------------------------------------------");
			System.out.print("  입력 >> ");
			menuNum = scanner.nextLine();
			System.out.println();
			
			switch(menuNum) {
			case "1":
				System.out.println("  [글쓰기]");
				System.out.println("  자유로운 생각을 담아보세요!");
				while(true) {
					while(true) {
						System.out.print("  제목(최대 30자) >> ");
						inputTitle = scanner.nextLine();
						if(inputTitle.length() > 30) {
							System.out.println("  30자 초과입니다 다시 제목을 입력해주세요.");
							break;
						}
						count++;
						
						break;
					}
					//count가 숫자가 올라가면 30자 초과가 아닌 정상적으로 입력이 완료됐다는 의미
					if(count > 0) {
						System.out.println("  제목 입력 완료");
						System.out.println();
						break;
					}
					System.out.println();
				}
				count = 0;
				
				while(true) {					
					while(true) {					
						System.out.println("  내용은 최대 100자 입니다.(공백 포함)");
						
						//내용 입력 받는 메소드를 inputContent라는 변수로 리턴받았음.
						
						inputContent = fdao.inputContents();
						if(inputContent.length() > 100) {
							System.out.println("  100자 초과입니다 \n  내용을 다시 입력해주세요");
							break;
						}
						System.out.println();
						//공백을 입력하면 다시 시작하게 만들기.			
						if(inputTitle.trim().isEmpty() && inputContent.trim().isEmpty()) {
							System.out.println("  제목 또는 내용을 입력하세요 \n  메뉴로 돌아갑니다.");
						}
						count++;
						break;
					}
					if(count > 0) {
						System.out.println("  내용 입력 완료");
						System.out.println();
						break;
					}
					System.out.println();
				}
				
				System.out.println("  게시판에 공유하시겠습니까?\n" + "  제목: " + inputTitle);
				System.out.println("  1.공유 / 2.취소");
				menuNum = scanner.nextLine();
				if(menuNum.equals("1")) {
					fdao.insertContents(nickname, inputTitle, inputContent);
					
					break;
				} else {
					System.out.println("  메뉴로 돌아갑니다.");
					break;
				}
				
			case "2":
				System.out.println("  [전체 게시글 목록 출력]");
				//셀렉트로 리스트 객체에 저장해서 모두 가져오기, 5개씩 출력 / 제목 닉네임 좋아요 수 표시
				//메뉴 만들어서 입력받기 1.이전 2.다음 3.게시글보기 4.게시글 검색하기 5.메뉴로 돌아가기
				//3-- 글 제목, 닉네임, 좋아요 수 \n 내용 \n 1.댓글작성하기 2.좋아요 누르기메뉴 3.친구한테 보내기 출력 \n댓글들 출력
				//4-- 1.제목 입력하기 2.작성자 닉네임 입력하기
				
				//전체 리스트 출력
				boardMenu(nickname);
				break;
			case "3":
				System.out.println("  [유저 검색]");
				//유저 이름 입력받기 리스트로 유저 이륾 모두 가져오기
				//1.자세히 보기 2.메뉴로 돌아가기
				//1을 누르면 제일 상단에는 유저 이름, 총 좋아요 수 그리고 아래로 내려가서 유저가 작성한 글들 모두 출력
				
				break;
			case "4":
				System.out.println("  [글 수정]");
				//본인이 작성한 글들 리스트 5개씩 전체 출력
				//1.이전 2.다음 3.수정할 게시글 번호 입력하기
				//3.제목, 내용 처음부터 다시 입력
				
				break;
			case "5": 
				System.out.println("  [메세지]");
				//1.메세지 보기 2.메세지 보내기
				//메세지 보기--- 전체메세지 출력, 1자세히 보기 ----안에 들어가서 답장하기 기능 만들기
				break;
			case "6":
				System.out.println("  [프로필 설정]");
				//출력 닉네임 / 총 좋아요 수 \n상태메시지
				//1.닉네임 수정 2.아이디 변경 3.회원탈퇴
				
				break;
			case "7":
				System.out.println("  프로그램을 종료합니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
		
	} //end of 메인메뉴
	
	public void boardMenu(String nickname) {		
		pageNum = 0;
//		lastPageNum = 0;
		
		while(true) {
			System.out.println("------------------------------------------------------------");
			int lastPage = fdao.showBoardList(pageNum);
			System.out.println("------------------------------------------------------------");
			System.out.println();
			System.out.println("  1.이전 | 2.다음 | 3.글보기 | 4.검색 | 5.메뉴로 돌아가기");
			menuNum = scanner.nextLine();
			
			
			switch(menuNum) {
			case "1":
				if(pageNum != 0) {
					pageNum -= 5;
				}
				break;
			case "2":
					if(pageNum+5 < lastPage) {
						pageNum += 5;
					} else {
						pageNum += 0;
					}
				break;
			case "3":
				
				break;
			case "4":
				break;
			case "5":
				System.out.println("  메뉴로 돌아갑니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}	
		}
	}// end of 
}
