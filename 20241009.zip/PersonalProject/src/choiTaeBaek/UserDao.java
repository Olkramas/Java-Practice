package choiTaeBaek;

import java.sql.SQLException;

public class UserDao extends DAO{
	
	public User login(String userId, String userPw) {
		String sql = "select  user_id, "
					+ "       nickname "
					+ "from   tbl_user "
					+ "where  user_id=? "
					+ "and    user_pw=? ";
		
		try {
			conn = getOpen();
			

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setNickName(rs.getString(2));
				user.setUserId(rs.getString(1));
				return user;
			}
			rs.close();
			pstmt.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
//			System.out.println("아이디 비밀번호가 정확하지 않습니다.");
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return null;
	}
	
	public void join(String userId, String userPw, String name, String nickName, String tel) {
		String sql = "insert into tbl_user ( "
				+ "          user_id, "
				+ "          user_pw, "
				+ "          nickname, "
				+ "          user_name, "
				+ "          user_tel ) "
				+ "   values( "
				+ "          ?, "
				+ "          ?, "
				+ "          ?, "
				+ "          ?, "
				+ "          ? ) ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			pstmt.setString(3, nickName);
			pstmt.setString(4, name);
			pstmt.setString(5, tel);
			int rows = pstmt.executeUpdate();
			
			if(rows > 0) {
				System.out.println("  회원가입 성공!");
			} else {
				System.out.println("  회원가입 실패\n  문의전화 010-xxxx-xxxx");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}
}
