package choiTaeBaek;

public class Comment {
	private String nickname;
	private String col_comment;
	private int boardNum;
	private String comment_date;
	
}
