package choiTaeBaek;

import java.util.Scanner;

public class FreeBoardForMain {
	Scanner scanner = new Scanner(System.in);
	UserDao udao = new UserDao();
	int menuNum;
	
	String inputTitle;
	String inputContent;
	
	
	
	public void start() {
		System.out.println("====FreeBoard에 오신것을 환영합니다====\n");
		System.out.println("  \"FreeBoard\"는 여러분들의 자유로운 "
				+ "  \n생각들을 담아내기 위해 만들어진 프로그램입니다:) \n\n");
		while(true) {
			System.out.println("================================");
			System.out.println("   1.로그인 | 2.회원가입 | 3.종료"); 
			System.out.println("================================");
			System.out.print("   입력 >> ");
			menuNum = Integer.parseInt(scanner.nextLine());
			System.out.println();
			
			switch(menuNum) {
			case 1:
				System.out.println("  [로그인]");
				//로그인 구현하기
				System.out.println("아이디 >> ");
				String userId = scanner.nextLine();
				
				System.out.println("비밀번호 >> ");
				String userPw = scanner.nextLine();
				
				//조건 만들어서 로그인 성공하면 menu()메소드 호출하기
				User checkAcc = udao.login(userId, userPw);

				if(checkAcc == null) {
					System.out.println("아이디 비밀번호가 정확하지 않습니다.");
					break;
				} else if(checkAcc.getUserId().equals(userId)) {
					System.out.println("환영합니다 " + checkAcc.getNickName() + "님");
					mainMenu();
				}
				return;
			case 2:
				System.out.println("  [회원가입]");
				//닉네임, 아이디 중복할 수 없음
				//둘중 하나 입력하고 중복이면 메뉴로 돌아감
				System.out.println("아이디 입력 >> ");
				String userIdJoin = scanner.nextLine();
				
				System.out.println("비밀번호 입력 >> ");
				String userPwJoin = scanner.nextLine();
				
				System.out.println("이름 입력 >> ");
				String userNameJoin = scanner.nextLine();
				
				System.out.println("닉네임 입력 >> ");
				String nickNameJoin = scanner.nextLine();
				
				System.out.println("전화번호 입력 >> ");
				String userTelJoin = scanner.nextLine();
				
				
				udao.join(userIdJoin, userPwJoin, userNameJoin, nickNameJoin, userTelJoin);
				
				System.out.println("  메뉴로 돌아갑니다");
				break;
			case 3:
				System.out.println("  프로그램을 종료합니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
	}
	public void mainMenu() {
		while(true) {
			System.out.println("----------------------------------------------------------------");
			System.out.println("  1.글쓰기 | 2.게시글 목록 | 3.유저 검색 | 4.글 수정 | 5.프로필 수정 | 6.종료  ");
			System.out.println("----------------------------------------------------------------");
			System.out.print("  입력 >> ");
			menuNum = Integer.parseInt(scanner.nextLine());
			System.out.println();
			
			switch(menuNum) {
			case 1:
				System.out.println("  [글쓰기]");
				System.out.println("  자유로운 생각을 담아보세요!");
				System.out.print("  제목 >> ");
				inputTitle = scanner.nextLine();
				System.out.println();
				
				System.out.println("  내용은 최대 100자 입니다.");
				System.out.print("  내용 >>");
				inputContent = scanner.nextLine();
				System.out.println();
				//공백을 입력하면 다시 시작하게 만들기.			
				if(inputTitle.trim().isEmpty() && inputContent.trim().isEmpty()) {
					System.out.println("제목 또는 내용을 입력하세요\n메뉴로 돌아갑니다.");
				}
					
				break;
				
				
			case 2:
				System.out.println("  [전체 게시글 목록 출력]");
				
				break;
			case 3:
				System.out.println("  [유저 검색]");
				
				break;
			case 4:
				System.out.println("  [글 수정]");
				
				break;
			case 5:
				System.out.println("  [프로필 수정]");
				
				break;
			case 6:
				System.out.println("  프로그램을 종료합니다.");
				return;
			default : System.out.println("  잘못된 값을 입력하셨습니다.\n  메뉴로 돌아갑니다.");
			}
		}
		
	}
}
