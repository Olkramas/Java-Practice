package choiTaeBaek;

public class Message {
	//보낸사람 닉네임
	String nickname;
	//받는사람 닉네임
	String recipient;
	String colMessage;
	String sendDate;
	
	public String getNickname() {return nickname;}
	public void setNickname(String nickname) {this.nickname = nickname;}
	public String getRecipient() {return recipient;}
	public void setRecipient(String recipient) {this.recipient = recipient;}
	public String getColMessage() {return colMessage;}
	public void setColMessage(String colMessage) {this.colMessage = colMessage;}
	public String getSendDate() {return sendDate;}
	public void setSendDate(String sendDate) {this.sendDate = sendDate;}

}
