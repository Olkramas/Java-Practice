package choiTaeBaek;

import java.sql.SQLException;

public class UserDao extends DAO{
	
	public User login(String userId, String userPw) {
		String sql = "select  user_id, "
					+ "       nickname "
					+ "from   tbl_user "
					+ "where  user_id=? "
					+ "and    user_pw=? ";
		
		try {
			conn = getOpen();
			

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setNickName(rs.getString(2));
				user.setUserId(rs.getString(1));
				return user;
			}
			rs.close();
			pstmt.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return null;
	}
	
	public void join(String userId, String userPw, String name, String nickName, String tel, String stateMessage) {
		String sql = "insert into tbl_user ( "
				+ "          user_id, "
				+ "          user_pw, "
				+ "          nickname, "
				+ "          user_name, "
				+ "          user_tel,"
				+ "          state_message ) "
				+ "   values( "
				+ "          ?, "
				+ "          ?, "
				+ "          ?, "
				+ "          ?, "
				+ "          ?,"
				+ "			 ? ) ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPw);
			pstmt.setString(3, nickName);
			pstmt.setString(4, name);
			pstmt.setString(5, tel);
			pstmt.setString(6, stateMessage);
			int rows = pstmt.executeUpdate();
			
			if(rows > 0) {
				System.out.println("  회원가입 성공!");
			} else {
				System.out.println("  회원가입 실패\n  문의전화 010-xxxx-xxxx");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	} //end of join method
	
	public User getUser(String nickname) {
		User user = new User();
		String sql = "select nickname, "
				+ "          total_like,"
				+ "          state_message,"
				+ "          user_id "
				+ "   from   tbl_user "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user.setNickName(rs.getString(1));
				user.setTotalLike(rs.getInt(2));
				user.setStateMessage(rs.getString(3));
			} else {
				System.out.println("존재하지 않는 닉네임입니다.");
			}
			rs.close();
			pstmt.close();
			return user;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user;
	}
	public User getUserForJoin(String id) {
		User user = new User();
		String sql = "select count(1) "
				+ "   from   tbl_user ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user.setNickName(rs.getString(1));
				user.setTotalLike(rs.getInt(2));
				user.setStateMessage(rs.getString(3));
			} else {
				System.out.println("존재하지 않는 닉네임입니다.");
			}
			rs.close();
			pstmt.close();
			return user;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user;
	}
	
	public void updateNick(String OrignalNickname, String updateNickname) {
		String sql = "update tbl_user "
				+ "   set    nickname=? "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, updateNickname);
			pstmt.setString(2, OrignalNickname);
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  닉네임 변경 성공");
				System.out.println("  변경된 닉네임은 재접속후에 사용가능합니다.");
				//성공 했을 경우에 댓글 작성자, 좋아요 누른 닉네임 모두 변경된 닉네임으로 업데이트 해야됨.
				//제일 마지막에 확인하기 그 전까지 닉네임 바꾸는 기능은 미완성
			} else {
				System.out.println("  닉네임 변경 실패");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}//end of updateNick
	
	public void updateState(String nickname, String updateState) {
		String sql = "update tbl_user "
				+ "   set    state_message=? "
				+ "   where  nickname=? ";
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, updateState);
			pstmt.setString(2, nickname);
			int rows = pstmt.executeUpdate();
			if(rows > 0) {
				System.out.println("  상태메시지 변경성공");
				
			} else {
				System.out.println("  상태메시지 변경실패");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void updateId(String checkId, String checkPw, String newId) {
		String sql = "update tbl_user "
				+ "   set    user_id=? "
				+ "   where  user_id=? "
				+ "   and    user_pw=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newId);
			pstmt.setString(2, checkId);
			pstmt.setString(3, checkPw);
			int rows = pstmt.executeUpdate();
			
			if(rows > 0) {
				System.out.println("  아이디 변경성공");
			} else {
				System.out.println("아이디 또는 비밀번호가 맞지 않습니다 다시 시도해주세요.");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void updatePw(String checkId, String checkPw, String newpw) {
		String sql = "update tbl_user "
				+ "   set    user_pw=? "
				+ "   where  user_id=? "
				+ "   and    user_pw=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newpw);
			pstmt.setString(2, checkId);
			pstmt.setString(3, checkPw);
			int rows = pstmt.executeUpdate();
			
			if(rows > 0) {
				System.out.println("  비밀번호 변경성공");
			} else {
				System.out.println("아이디 또는 비밀번호가 맞지 않습니다 다시 시도해주세요.");
			}
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void delUser(String checkId, String checkPw) {
		String sql = "delete from tbl_user "
				+ "   where  user_id=? "
				+ "   and    user_pw=? ";
		
		try {
			conn = getOpen();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, checkId);
			pstmt.setString(2, checkPw);
			int rows = pstmt.executeUpdate();
			
			pstmt.close();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				getClose();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//닉네임 변경시 유저의 모든 로그를 변경된 닉네임으로 업데이트하는 메소드
	public void updateAllLog() {
		
	}
	//회원탈퇴시 유저의 모든 로그를 삭제하는 메소드
	public void delAllLog() {
		
	}
}
